"""Bounded document readers for the Week 5 comparison.

Each worker extracts evidence from exactly one document.  Workers do not return
an impact verdict: an unreadable document, a single finding, or a conflict is
not enough to decide the assessment.  The parent receives every reader's
evidence and makes one cross-document assessment with the normal response
validator.
"""

from __future__ import annotations

import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from llm import complete_reply, record_capability_call
from schema import Document, ProposedChange, Response
from validation import insufficient_evidence, validate_assessment


def _json_payload(text: str) -> dict[str, Any]:
    """Parse a JSON object, accepting the fenced output models often return."""

    cleaned = text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()
    payload = json.loads(cleaned)
    if not isinstance(payload, dict):
        raise ValueError("subagent response was not a JSON object")
    return payload


def _document_prompt(document: Document, proposed_changes: list[ProposedChange]) -> str:
    """Build the isolated evidence-extraction prompt for one document."""

    return f"""You are a document-analysis subagent for a nuclear uprate review.

Analyze only this document and the proposed changes. Do not use outside
knowledge. You are a reader, not a decision maker. Return one JSON object with
exactly these fields:
{{
  "document_id": "{document.id}",
  "readable": true,
  "quotes": [{{"section":"...", "page":null, "quote":"..."}}],
  "values": ["value or relationship copied from the document"],
  "limitations": ["..."],
  "unreadable_reason": "..."
}}

Copy quotes exactly enough to be found in the source. Extract relevant numeric
values, units, limits, and relationships without interpreting them. Set
readable to false when OCR or scan quality makes the relevant text unreliable;
do not turn a fragment into an impact. Use empty lists when there is no relevant
evidence. The parent will decide the outcome after comparing all documents.

Document ID: {document.id}
Document title: {document.title}
Document text:
{document.text}

Proposed changes:
{json.dumps([change.model_dump(exclude_none=True) for change in proposed_changes], indent=2)}
"""


def _analyze_document(
    document: Document,
    proposed_changes: list[ProposedChange],
) -> tuple[str, dict[str, Any]]:
    """Run one isolated reader and validate its source-local evidence."""

    record_capability_call()
    try:
        evidence = _json_payload(complete_reply(_document_prompt(document, proposed_changes)))
        if evidence.get("document_id") != document.id:
            raise ValueError("reader returned the wrong document ID")
        if not isinstance(evidence.get("readable"), bool):
            raise ValueError("reader readable flag must be boolean")
        quotes = evidence.get("quotes", [])
        if not isinstance(quotes, list):
            raise ValueError("reader quotes must be a list")
        for quote in quotes:
            if not isinstance(quote, dict) or not quote.get("quote"):
                raise ValueError("reader quotes must include non-empty quote text")
            if quote["quote"].casefold() not in document.text.casefold():
                raise ValueError("reader returned a quote not present in its document")
        return document.id, evidence
    except Exception as exc:
        return document.id, {
            "document_id": document.id,
            "readable": False,
            "quotes": [],
            "values": [],
            "limitations": [],
            "unreadable_reason": f"Reader failure: {type(exc).__name__}",
        }


def _parent_prompt(
    proposed_changes: list[ProposedChange],
    evidence: list[dict[str, Any]],
) -> str:
    """Build the cross-document adjudication prompt."""

    return f"""You are the parent reviewer for a nuclear uprate assessment.

Make the final assessment using all reader evidence below and the original
documents. Readers only extracted evidence; they did not decide whether an
impact exists. Compare documents, identify conflicting values or conclusions,
and treat unreadable evidence as a limitation rather than support for an impact.
Do not resolve a conflict by guessing or silently choosing a value. Return only
valid JSON matching this schema:
{{
  "outcome": "candidate_impacts|no_impact_identified|insufficient_evidence|declined",
  "affected_items": [{{"item":"...", "type":"system|function|component|requirement|document",
    "reason":"...", "citations":[{{"document_id":"...", "section":"...", "page":null, "quote":"..."}}],
    "confidence":"low|medium|high", "needs_sme_review":true}}],
  "conclusion":"...", "missing_information":[], "limitations":[],
  "needs_sme_review":true
}}

Every candidate impact must be supported by exact source quotes. If relevant
evidence is unreadable or documents conflict, use insufficient_evidence when
that prevents a reliable determination and explain the issue in limitations or
missing_information. Never treat a reader's finding as a verdict.

Proposed changes:
{json.dumps([change.model_dump(exclude_none=True) for change in proposed_changes], indent=2)}

Reader evidence:
{json.dumps(evidence, indent=2)}
"""


def assess_with_subagents(
    documents: list[Document],
    proposed_changes: list[ProposedChange],
) -> Response:
    """Assess documents with bounded readers and one cross-document parent."""

    if not documents or not proposed_changes:
        return Response(
            outcome="insufficient_evidence",
            conclusion="Documents and proposed changes are required for assessment.",
            missing_information=["Documents and proposed changes"],
            needs_sme_review=True,
        )

    try:
        configured_workers = int(os.getenv("SUBAGENT_MAX_WORKERS", "4"))
    except ValueError:
        configured_workers = 4
    max_workers = max(1, min(configured_workers, len(documents)))
    results: list[tuple[str, dict[str, Any]]] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(_analyze_document, document, proposed_changes)
            for document in documents
        ]
        for future in as_completed(futures):
            source, response = future.result()
            results.append((source, response))

    results.sort(key=lambda result: result[0])
    evidence = [payload for _source, payload in results]
    try:
        record_capability_call()
        response = validate_assessment(
            complete_reply(_parent_prompt(proposed_changes, evidence)), documents
        )
        response.sources = [document.id for document in documents]
        return response
    except Exception as exc:
        return insufficient_evidence(
            f"Parent assessment failure: {type(exc).__name__}",
            sources=[document.id for document in documents],
        )
