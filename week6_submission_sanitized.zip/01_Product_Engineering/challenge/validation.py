"""Deterministic validation for model-produced impact assessments."""

from __future__ import annotations

import json
import re
import unicodedata
from collections.abc import Iterable

from schema import Document, Response


def _normalise_text(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip().lower()


def _legible_quote(value: str) -> bool:
    """Reject obvious OCR failure markers before citation matching.

    Presence in the source is necessary, but it is not sufficient: replacement
    characters and control bytes are evidence that the source itself is not
    readable.  This deliberately conservative check is not a language or
    engineering-content judge; it only rejects unambiguous encoding/OCR
    failures without making a model call.
    """

    if not value.strip():
        return False
    for character in value:
        category = unicodedata.category(character)
        if character in "�□" or (category.startswith("C") and character not in "\t\n\r"):
            return False
    return True


def _parse_json(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()[1:]
        if lines and lines[-1].strip() == "```":
            lines.pop()
        cleaned = "\n".join(lines).strip()
    payload = json.loads(cleaned)
    if not isinstance(payload, dict):
        raise ValueError("model response was not a JSON object")
    return payload


def validate_assessment(text: str, documents: Iterable[Document]) -> Response:
    """Parse and fail closed when an impact lacks source-supported evidence.

    Every claimed impact needs at least one citation. Citation IDs must be in
    the request, and every citation must include a quote found in that source.
    """

    response = Response.model_validate(_parse_json(text))
    documents_by_id = {document.id: document.text for document in documents}

    if response.outcome == "candidate_impacts" and not response.affected_items:
        raise ValueError("candidate impacts contained no impact items")
    if response.outcome != "candidate_impacts" and response.affected_items:
        raise ValueError("non-candidate outcome contained impact items")

    for item in response.affected_items:
        if not item.citations:
            raise ValueError(f"impact {item.item!r} has no citation")
        for citation in item.citations:
            source_text = documents_by_id.get(citation.document_id)
            if source_text is None:
                raise ValueError(
                    f"citation references document outside the supplied context: "
                    f"{citation.document_id}"
                )
            if not citation.quote or not _legible_quote(citation.quote):
                raise ValueError(
                    f"citation quote is illegible in document {citation.document_id}"
                )
            if _normalise_text(citation.quote) not in _normalise_text(source_text):
                raise ValueError(
                    f"citation quote is not present in document {citation.document_id}"
                )

    response.sources = list(documents_by_id)
    return response


def insufficient_evidence(message: str, *, sources: list[str] | None = None) -> Response:
    """Build the stable public response used for validation failures."""

    return Response(
        outcome="insufficient_evidence",
        conclusion="The response did not contain source-supported evidence for an assessment.",
        limitations=[message],
        needs_sme_review=True,
        sources=sources or [],
    )
