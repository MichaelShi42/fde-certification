"""Small, domain-neutral building blocks for conversational evals.

The scenarios and the state verifier belong to the application.  This module
only owns the reusable plumbing: recording a trajectory, driving a scripted or
model user, and aggregating trajectory scorers into a normal harness report.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from math import comb
from typing import Any, Callable, Mapping, Sequence


@dataclass
class Scenario:
    """A goal, the facts a user withholds, and the way success is checked."""

    name: str
    capability: str
    goal: str
    opening: str
    knows: dict[str, str] = field(default_factory=dict)
    success: list[str] = field(default_factory=list)
    must_not: list[str] = field(default_factory=list)
    expected_tools: list[str] = field(default_factory=list)
    check: str = "text"
    judge_question: str = ""
    judge_words: tuple[str, str] = ("YES", "NO")
    max_turns: int = 6


@dataclass
class Trajectory:
    """Evidence from one simulated conversation."""

    scenario: Scenario
    turns: list[tuple[str, str]] = field(default_factory=list)
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    ended_because: str = ""

    @property
    def transcript(self) -> str:
        return "\n".join(f"{speaker}: {text}" for speaker, text in self.turns)

    @property
    def agent_said(self) -> str:
        return " ".join(text for speaker, text in self.turns if speaker == "agent").lower()

    @property
    def last_agent_reply(self) -> str:
        for speaker, text in reversed(self.turns):
            if speaker == "agent":
                return text
        return ""

    @property
    def tools_used(self) -> list[str]:
        return [str(call.get("tool", "")) for call in self.tool_calls]


SATISFIED = "__satisfied__"
GAVE_UP = None


def user_is_satisfied(traj: Trajectory) -> bool:
    """Cheap shared text check; domain-specific checks should be stricter."""
    said = traj.agent_said
    return bool(traj.scenario.success) and all(
        phrase.lower() in said for phrase in traj.scenario.success
    )


def simulate(
    scenario: Scenario,
    agent: Callable[[Trajectory], str],
    user: Callable[[Trajectory], str | None],
    max_turns: int | None = None,
) -> Trajectory:
    """Run an agent/user conversation and retain failures instead of hiding them."""
    trajectory = Trajectory(scenario=scenario)
    limit = scenario.max_turns if max_turns is None else max_turns
    trajectory.turns.append(("user", scenario.opening))
    for _ in range(limit):
        try:
            reply = str(agent(trajectory) or "")
        except Exception as exc:  # a failed agent is a failed trajectory
            trajectory.errors.append(f"{type(exc).__name__}: {exc}")
            trajectory.ended_because = "agent raised"
            return trajectory
        trajectory.turns.append(("agent", reply))
        if user_is_satisfied(trajectory):
            trajectory.ended_because = "goal reached"
            return trajectory
        try:
            follow_up = user(trajectory)
        except Exception as exc:
            trajectory.errors.append(f"{type(exc).__name__}: {exc}")
            trajectory.ended_because = "user raised"
            return trajectory
        if follow_up == SATISFIED:
            trajectory.ended_because = "goal reached"
            return trajectory
        if follow_up is GAVE_UP or follow_up is None:
            trajectory.ended_because = "user gave up"
            return trajectory
        trajectory.turns.append(("user", str(follow_up)))
    trajectory.ended_because = "turn limit"
    return trajectory


def scripted_user(traj: Trajectory) -> str | None:
    """Reveal one withheld fact per turn, then allow two progress updates."""
    user_messages = sum(1 for speaker, _ in traj.turns if speaker == "user") - 1
    facts = list(traj.scenario.knows.items())
    if user_messages < len(facts):
        key, value = facts[user_messages]
        return f"The {key} is {value}."
    if user_messages < len(facts) + 2:
        return "Any update?"
    return GAVE_UP


def transcript_agent(system_prompt: str, run_agent: Callable, *, tools=None):
    """Adapt a messages-based agent to the ``agent(trajectory)`` contract."""

    def agent(traj: Trajectory) -> str:
        messages = [{"role": "system", "content": system_prompt}]
        messages.extend(
            {"role": "user" if speaker == "user" else "assistant", "content": text}
            for speaker, text in traj.turns
        )
        reply, calls = run_agent(messages, tools=tools)
        traj.tool_calls.extend(calls or [])
        return reply

    return agent


def text_check(traj: Trajectory) -> float:
    """Check expected tools, required phrases, and forbidden phrases."""
    scenario = traj.scenario
    tools_ok = all(tool in traj.tools_used for tool in scenario.expected_tools)
    required_ok = all(phrase.lower() in traj.agent_said for phrase in scenario.success)
    forbidden = any(phrase.lower() in traj.agent_said for phrase in scenario.must_not)
    return float(tools_ok and required_ok and not forbidden)


def binary_judge(traj: Trajectory, llm_kwargs: Mapping[str, Any]) -> float:
    """Ask a model for a binary verdict when a function cannot express the check."""
    if traj.scenario.check != "judge":
        return float("nan")
    import litellm

    yes, no = (word.upper() for word in traj.scenario.judge_words)
    prompt = (
        f"{traj.scenario.judge_question}\n\nConversation:\n{traj.transcript}\n\n"
        f"Tools called: {', '.join(traj.tools_used) or 'none'}\n\nOne word:"
    )
    reply = litellm.completion(
        **dict(llm_kwargs), timeout=600,
        messages=[{"role": "user", "content": prompt}], max_tokens=20,
    ).choices[0].message.content or ""
    verdict = reply.upper()
    if no in verdict:
        return 0.0
    return float(yes in verdict)


def used_tools(traj: Trajectory) -> float:
    return float(all(tool in traj.tools_used for tool in traj.scenario.expected_tools))


def efficiency(traj: Trajectory) -> float:
    turns = sum(1 for speaker, _ in traj.turns if speaker == "agent")
    return 0.0 if traj.ended_because != "goal reached" else min(1.0, 2 / max(turns, 1))


def no_repeated_questions(traj: Trajectory) -> float:
    stopwords = {"the", "a", "is", "what", "your", "you", "can", "please"}
    asks = [
        frozenset(text.lower().split()) - stopwords
        for speaker, text in traj.turns
        if speaker == "agent" and "?" in text
    ]
    return float(not any(a and len(a & b) / len(a | b) > 0.6 for i, a in enumerate(asks) for b in asks[i + 1:]))


def pass_k(successes: int, trials: int, k: int) -> float:
    """Estimate the chance that k sampled attempts all succeed."""
    if trials < 0 or successes < 0 or successes > trials or k < 0 or k > trials:
        raise ValueError("successes, trials, and k must describe a valid sample")
    if k == 0:
        return 1.0
    return comb(successes, k) / comb(trials, k) if successes >= k else 0.0


def capability_report(scenarios: Sequence[Scenario], trajectories: Sequence[Trajectory], scorers: Mapping[str, Callable], *, name: str = "run", capabilities: Sequence[str] | None = None):
    """Return a harness report whose case rows are trajectory scorer results."""
    from . import harness

    if len(scenarios) != len(trajectories):
        raise ValueError("scenarios and trajectories must have the same length")
    cases = [{"input": scenario.opening, "output": scenario.name, "capability": scenario.capability} for scenario in scenarios]
    fingerprint = harness.fingerprint(cases, scorers)
    results = []
    totals = {label: 0.0 for label in scorers}
    for index, (case, trajectory) in enumerate(zip(cases, trajectories)):
        scores = {}
        for label, scorer in scorers.items():
            try:
                scores[label] = max(0.0, min(1.0, float(scorer(trajectory))))
            except Exception:
                scores[label] = 0.0
        totals = {label: totals[label] + scores[label] for label in scorers}
        results.append(harness.Result(index, case["input"], case["output"], trajectory.last_agent_reply, scores=scores))
    capability_names = list(capabilities or sorted({s.capability for s in scenarios}))
    capability_means = {
        capability: sum(
            result.scores.get("passed", 0.0)
            for scenario, result in zip(scenarios, results)
            if scenario.capability == capability
        ) / max(1, sum(s.capability == capability for s in scenarios))
        for capability in capability_names
    }
    report = harness.RunReport(
        name=name,
        fingerprint=fingerprint,
        n=len(results),
        means={
            **{label: total / max(1, len(results)) for label, total in totals.items()},
            **capability_means,
        },
        meta={"scorers": list(scorers), "capabilities": capability_names},
        results=results,
    )
    report.meta["capability_means"] = capability_means
    return report


def column_means(report) -> dict[str, float]:
    """Average each scorer column from a saved or live harness report."""
    scorer_names = report.meta.get("scorers", report.means.keys())
    return {name: report.means[name] for name in scorer_names if name in report.means}


def make_llm_user(llm_kwargs: Mapping[str, Any], satisfied_signal=SATISFIED, on_token=None):
    """Create a model-driven user compatible with :func:`simulate`."""
    import litellm

    def user(traj: Trajectory):
        known = "\n".join(f"- {key}: {value}" for key, value in traj.scenario.knows.items()) or "- nothing"
        prompt = f"Goal: {traj.scenario.goal}\nFacts only if asked:\n{known}\nConversation:\n{traj.transcript}\nReply DONE if satisfied, GIVE UP if stuck, otherwise reply as the user."
        request = dict(llm_kwargs)
        request.update(timeout=600, messages=[{"role": "user", "content": prompt}])
        if on_token is None:
            response = litellm.completion(**request)
            text = (response.choices[0].message.content or "").strip()
        else:
            text = ""
            for chunk in litellm.completion(**request, stream=True):
                token = getattr(chunk.choices[0].delta, "content", None) or ""
                text += token
                on_token(traj, text)
            text = text.strip()
        if "GIVE UP" in text.upper():
            return GAVE_UP
        if "DONE" in text.upper():
            return satisfied_signal
        return text

    return user
