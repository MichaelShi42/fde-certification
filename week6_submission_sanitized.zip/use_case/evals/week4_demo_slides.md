---
marp: true
theme: default
paginate: true
size: 16:9
title: Uprate Impact Mapper — Five-Minute Demo
description: A focused Week 4 demo of the uprate-impact review workflow
---

<style>
section { font-family: Aptos, Arial, sans-serif; color: #172033; font-size: 23px; padding: 42px 60px 30px; }
h1, h2 { color: #123b5d; }
h1 { font-size: 1.65em; }
h2 { font-size: 1.18em; }
strong { color: #0b6b68; }
.small { font-size: 0.68em; color: #52606d; }
.metric { font-size: 2.2em; font-weight: 700; color: #0b6b68; }
.warning { color: #8a4b08; background: #fff4d6; padding: 0.45em 0.75em; border-left: 6px solid #d97706; }
.good { color: #166534; background: #e9f8ef; padding: 0.45em 0.75em; border-left: 6px solid #16a34a; }
table { font-size: 0.78em; }
</style>

# Uprate Impact Mapper

## Five-minute demo

**Traceable candidate impacts from technical evidence**

<br>

**Reduce evidence-search time without overstating what the records prove.**

<!-- Speaker notes: Keep this title on screen briefly. Move immediately to the problem. -->

---

## The problem

### One engineer. One workflow. A large cost.

**The person:** A nuclear system engineer evaluating a proposed extended power uprate.

**Today:** Search documents, interview plant engineers, connect evidence, and prepare findings for review.

<div class="warning"><strong>Cost:</strong> 1,000–2,000 person-hours per system evaluation.</div>

**Scale:** roughly 20 evaluations over five years; engineers are overextended and relationships can be missed.

<!--
Speaker notes — 0:00–1:00
“Let me start with one person and one workflow. A system engineer evaluating a proposed nuclear power uprate has to determine which systems, functions, components, requirements, and supporting documents may be affected.

Today, that engineer manually searches and compares plant documentation and interviews plant engineers to understand the relationships. A single system evaluation can require approximately 1,000 to 2,000 person-hours. At roughly 20 evaluations over five years, that creates a scaling problem: engineers are overextended, profitability is affected, and important relationships can be missed.

The problem is not that engineers lack judgment. It is that too much time is spent finding and connecting the evidence needed to begin the judgment.”
-->

---

## DEMO TIME!

<!--
Speaker notes — 1:00–2:00
“Now I’ll show the working application. I upload the relevant text documents, describe the proposed change, and select Assess impacts.

The result is designed for a reviewer. It gives us an outcome, then separates each potential impact into a card with the reason and supporting document sections. The system is not approving the change. It is preparing a traceable candidate list for SME review.

I’ll also run an unreadable OCR example. This is important because a system that sees words like pump, flow, and margin could easily produce a plausible but unsupported answer. Here the expected behavior is to report insufficient evidence and make the limitation visible. If the baseline volunteers candidate impacts, show that as a caught failure rather than hiding it.”

During the live demo, keep this slide hidden and show the running application itself.
-->

---

## The numbers

### First baseline

| Measure | Result |
| --- | ---: |
| Correct outcome (including no-claims cases) | **2 / 6 = 33%** |
| Exact impact-list agreement | **report per case** |
| Cases | **6** |
| 95% bootstrap interval | **0.00–0.67** |
| Valid structure | **6 / 6 = 100%** |
| Source-supported readable citations | **4 / 6 = 67%** |
| Evidence safety | **3 / 6 = 50%** |
| LLM judge | **0.67** |
| Judge separation: accepted / wrong | **1.00 / 0.00** |
| Judge agreement with SME | **16 / 20 = 0.80** |
| Majority-class chance floor | **0.60** |

<div class="warning"><strong>Interpretation:</strong> two cases matched the corrected outcome contract; four need correction or further review. The separate impact-list check catches the right label with the wrong systems. The OCR case is a volunteered baseline failure. This is not a production or annual failure rate.</div>

**Next measurement:** more independently reviewed OCR, incomplete-calculation, and insufficient-evidence cases.

<!--
Speaker notes — 2:00–3:30
“Here is the corrected baseline. The headline includes the no-claims rule: 0.33, or two of six reviewed cases. A separate impact-list check catches the case where the category is right but the systems are wrong. The bootstrap 95% interval is 0.00 to 0.67, which is wide because six cases cannot establish a stable rate.

In the units a reviewer can understand, this means two cases matched and four did not. The evidence-safety metric is separate: a cautious label does not earn credit if the answer still asserts impacts, and a citation does not earn credit unless its quote appears in the source and is readable.

That does not mean the production system is 50% accurate. It is not a customer-impact rate or an annual failure rate. It is a first baseline on six cases. The other checks were stronger: all six responses had the required structure and all six had traceable document citations.

The judge scored the endpoint at 0.67, but I am keeping it as supporting evidence. We also found four judge/SME disagreements to inspect individually. The important next step is a larger independently reviewed set, particularly cases involving unreadable OCR and insufficient evidence.”
-->

---

## What is next—and what I need from whom

### Next

- Expand the reviewed test set.
- Add an accepted SME answer key.
- Measure impact recall.
- Keep the focused upload-and-review UI.
- Run paired SME reviews and record manual versus tool-assisted review time.

### The asks

| From whom | What is needed |
| --- | --- |
| EPU SME | Sanitized assessments and answer key |
| Data owner | Approved excerpts and representative cases |
| IT / platform | Runtime and model-gateway access; no public internet, no Docker, local GitLab clone, LDAP, Azure Gov gateway |
| Data approver | Permission for controlled records and model use |

<div class="good"><strong>Decision:</strong> proceed as a review aid with human approval—not as an autonomous engineering decision-maker.</div>

<!--
Speaker notes — 3:30–5:00
“The next step is not simply to add more model capability. It is to strengthen the evidence base. I need a larger independently reviewed set, including OCR and incomplete-evidence cases, and an accepted SME answer key so impact recall can be measured.

From the extended-power-uprate SME, I need the sanitized historical assessments and the answer key, and I want to run paired reviews on real uprate work now. For each pair I will record manual minutes, tool minutes, rework, and whether the SME accepted the result. From the data owner, I need confirmation that the documents and excerpts represent the real workflow. From the IT or platform owner, I need the approved local runtime and Azure Gov gateway access: no public internet, no Docker, local GitLab clone, and LDAP. Finally, the relevant approver needs to authorize the controlled records and model use.

The decision at this stage is to continue as a review aid with human approval. The system can reduce search and evidence-assembly effort, but the SME remains responsible for the engineering conclusion.”

Close with: “What would you do differently on Monday if this number is right? And what would convince you that it is wrong?”
-->
