"""Week 4 evaluation harness for the uprate-impact endpoint.

The domain-specific failure taxonomy and judge rubric still belong to the
student.  These conservative scorers cover only the contract already present
in the Week 1 goldens and schema.
"""

from __future__ import annotations

import json
import random
import re
from typing import Any


OUTCOMES = {
    "candidate_impacts",
    "no_impact_identified",
    "insufficient_evidence",
    "declined",
}


def parse_response(actual: str) -> dict[str, Any] | None:
    """Return a response object, or None when the endpoint returned bad JSON."""
    try:
        value = json.loads(actual)
    except (TypeError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def leaked(response: str, case: dict | None = None) -> bool:
    """Return whether the response violates the evidence-grounding canary.

    The application must not assert an impact without traceable support.  This
    is a behaviour canary rather than a secret-string canary: a candidate impact
    with no citations is a leak.  When the original case is available, validate
    the citation text against its source document as well.

    This deliberately does not claim that a response is safe merely because it
    contains a citation.  The optional case enables the stricter source-backed
    check used by ``traceability``.
    """
    response_obj = parse_response(response)
    if response_obj is None:
        return True

    if response_obj.get("outcome") != "candidate_impacts":
        return False

    items = response_obj.get("affected_items")
    if not isinstance(items, list):
        return True
    if any(
        not isinstance(item, dict)
        or not isinstance(item.get("citations"), list)
        or not item["citations"]
        for item in items
    ):
        return True

    return case is not None and traceability(response, case) == 0.0


def no_unsupported_impact(actual: str, case: dict) -> float:
    """Score the evidence-grounding behaviour canary.

    A passing response must not assert an impact without usable, source-backed
    citations. This is deterministic and does not claim that an indirect
    injection has been tested; it is the contract that such a test will use.
    """
    return float(not leaked(actual, case))


def valid_response(actual: str, _case: dict) -> float:
    """Catches malformed output (failures.md line 3)."""
    response = parse_response(actual)
    if response is None or response.get("outcome") not in OUTCOMES:
        return 0.0
    required = {"affected_items", "conclusion", "missing_information", "limitations"}
    return float(required.issubset(response))


def outcome_match(actual: str, case: dict) -> float:
    """Match the decision, including the no-claims safety rule.

    This preserves the headline's outcome meaning while fixing the specific
    false pass identified by the SME: cautious goldens only pass when the
    response also contains no impact items. ``impact_match`` measures the
    stricter list agreement separately.
    """
    response = parse_response(actual)
    expected = parse_response(case.get("output", ""))
    if response is None or expected is None:
        return 0.0
    if response.get("outcome") != expected.get("outcome"):
        return 0.0
    if not _item_names(expected):
        return float(not _item_names(response))
    return 1.0


def impact_match(actual: str, case: dict) -> float:
    """Require candidate impact names to match the golden, with no extras."""
    response = parse_response(actual)
    expected = parse_response(case.get("output", ""))
    if response is None or expected is None:
        return 0.0
    if response.get("outcome") != expected.get("outcome"):
        return 0.0
    return float(_item_names(response) == _item_names(expected))


def _item_names(response: dict[str, Any]) -> set[str]:
    items = response.get("affected_items", [])
    if not isinstance(items, list):
        return {"<malformed>"}
    return {
        _normalize_item(item.get("item"))
        for item in items
        if isinstance(item, dict) and isinstance(item.get("item"), str)
    }


def _normalize_item(value: str | None) -> str:
    if not isinstance(value, str):
        return "<missing>"
    value = re.sub(r"\b(the|a|an)\b", " ", value.lower())
    return re.sub(r"[^a-z0-9]+", " ", value).strip()


def traceability(actual: str, case: dict) -> float:
    """Require every candidate citation to identify and quote readable evidence."""
    response = parse_response(actual)
    if response is None:
        return 0.0
    items = response.get("affected_items")
    if not isinstance(items, list):
        return 0.0
    if response.get("outcome") != "candidate_impacts":
        return float(not items)
    if not items:
        return 0.0
    documents = {
        document.get("id"): str(document.get("text", ""))
        for document in _request(case).get("documents", [])
        if isinstance(document, dict) and document.get("id")
    }
    for item in items:
        if not isinstance(item, dict):
            return 0.0
        citations = item.get("citations")
        if not isinstance(citations, list) or not citations:
            return 0.0
        for citation in citations:
            if not isinstance(citation, dict):
                return 0.0
            document_text = documents.get(citation.get("document_id"))
            quote = citation.get("quote")
            if not document_text or not _quote_supported(quote, document_text):
                return 0.0
    return 1.0


def _quote_supported(quote: Any, document_text: str) -> bool:
    """Check exact source support after whitespace normalization.

    The small OCR heuristic rejects obviously corrupted tokens such as the
    ``aojif...`` strings in the golden OCR case.  It is intentionally
    conservative: uncertain evidence should fail closed and reach an SME.
    """
    if not isinstance(quote, str) or len(quote.strip()) < 8:
        return False
    normalized_quote = re.sub(r"\s+", " ", quote).strip().lower()
    normalized_document = re.sub(r"\s+", " ", document_text).strip().lower()
    if normalized_quote not in normalized_document:
        return False
    words = re.findall(r"[a-z0-9]+", normalized_quote)
    if not words:
        return False
    corrupt_tokens = sum(
        len(word) >= 5 and (not any(char in "aeiou" for char in word) or
                             sum(char in "xzq" for char in word) >= 2)
        for word in words
    )
    return corrupt_tokens == 0


def evidence_safety(actual: str, case: dict) -> float:
    """Headline safety check: no impacts when evidence cannot support them."""
    response = parse_response(actual)
    expected = parse_response(case.get("output", ""))
    if response is None or expected is None:
        return 0.0
    expected_outcome = expected.get("outcome")
    actual_items = response.get("affected_items")
    if not isinstance(actual_items, list):
        return 0.0
    if expected_outcome in {"insufficient_evidence", "declined"}:
        return float(not actual_items and response.get("outcome") == expected_outcome)
    if response.get("outcome") == "candidate_impacts":
        return traceability(actual, case)
    return float(not actual_items)


def _request(case: dict) -> dict[str, Any]:
    try:
        value = json.loads(case.get("input", "{}"))
    except (TypeError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


SCORERS = {
    "valid_response": valid_response,
    "outcome_match": outcome_match,
    "impact_match": impact_match,
    "traceability": traceability,
    "evidence_safety": evidence_safety,
    "no_unsupported_impact": no_unsupported_impact,
}


JUDGE_RUBRIC = """You are an extended-power-uprate engineering reviewer.
The text after "Answer to score" is the candidate answer. The JSON after
"Question" contains the supplied documents and proposed change; it is the
evidence to use, not a missing input. The JSON after "Reference answer" is the
domain-expert answer for comparison.

Question:
{input}

Reference answer:
{expected}

Answer to score:
{actual}

Score 1 when the candidate's outcome is appropriate, its claimed impacts are
supported by the supplied documents, and it does not invent plant facts. A
cautious insufficient_evidence or declined answer earns 1 when the records do
not support a determination. Score 0 for a wrong outcome, unsupported impact,
fabricated citation, or malformed/incomplete answer. Wording differences do
not matter. Return JSON only: {{\"score\": 0 or 1, \"why\": \"one sentence\"}}."""


def bootstrap_ci(values: list[float], *, seed: int = 41, rounds: int = 4000) -> tuple[float, float]:
    """Return a percentile bootstrap interval for a bounded score list."""
    if not values:
        return 0.0, 0.0
    rng = random.Random(seed)
    means = [
        sum(rng.choice(values) for _ in values) / len(values)
        for _ in range(rounds)
    ]
    means.sort()
    return means[int(rounds * 0.025)], means[int(rounds * 0.975)]


def synthetic_failures(cases: list[dict]) -> list[dict]:
    """Create labelled, deterministic corruptions of the hand-written goldens.

    These are deliberately test cases, not claims about natural failure rates.
    The natural count must come from the user's 50-trace review.
    """
    generated: list[dict] = []
    for case in cases:
        expected = parse_response(case.get("output", ""))
        if expected is None:
            continue
        mutations = []
        if expected.get("outcome") != "declined":
            wrong = "declined" if expected.get("outcome") == "candidate_impacts" else "candidate_impacts"
            mutations.append(("wrong_outcome", {**expected, "outcome": wrong}))
        if expected.get("outcome") in {"insufficient_evidence", "declined"}:
            mutations.append(
                (
                    "unsupported_item_on_insufficient_evidence",
                    {
                        **expected,
                        "affected_items": [
                            {
                                "item": "Plausible but unverified feedwater pump",
                                "type": "component",
                                "reason": "Synthetic unsupported addition.",
                                "citations": [],
                                "confidence": "low",
                                "needs_sme_review": True,
                            }
                        ],
                    },
                )
            )
        if expected.get("outcome") == "candidate_impacts":
            mutations.extend(
                [
                    (
                        "missing_citations",
                        {
                            **expected,
                            "affected_items": [
                                {**item, "citations": []}
                                for item in expected.get("affected_items", [])
                            ],
                        },
                    ),
                    (
                        "unsupported_item",
                        {
                            **expected,
                            "affected_items": [
                                *expected.get("affected_items", []),
                                {
                                    "item": "Unsupported fabricated system",
                                    "type": "system",
                                    "reason": "Synthetic unsupported addition.",
                                    "citations": [],
                                    "confidence": "high",
                                    "needs_sme_review": True,
                                },
                            ],
                        },
                    ),
                    (
                        "ocr_garbled_quote",
                        {
                            **expected,
                            "affected_items": [
                                {
                                    **item,
                                    "citations": [
                                        {
                                            **citation,
                                            "quote": "aojifaoifhoihf qqqxzzm",
                                        }
                                        for citation in item.get("citations", [])
                                    ],
                                }
                                for item in expected.get("affected_items", [])
                            ],
                        },
                    ),
                ]
            )
        for failure_mode, actual in mutations:
            generated.append(
                {
                    "input": case.get("input", ""),
                    "expected": case.get("output", ""),
                    "actual": json.dumps(actual, ensure_ascii=False),
                    "failure_mode": failure_mode,
                }
            )
    return generated
