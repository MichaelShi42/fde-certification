# Someone else's ecosystem

Where your application would actually run, inside your actual firm.

> **Week 1 starts this file. Week 9 finishes it.**
> TC1 Step 6 asks eight questions. The full Week 9 checklist has around thirty,
> and the eight are a strict subset — so nothing here gets thrown away.

Describe patterns, not specifics. "On-prem OpenShift, images from an internal
registry, no public egress" is useful to everyone and identifies nobody. Never
put real hostnames, IPs, or architecture diagrams in this file.

---

## Week 1 — the first eight questions

<!-- Answered in TC1 Step 6. Bring these back from a real conversation. -->

**Who did you ask?** (role, not name)

IT infrastructure maintainer

| # | Question | Answer |
| :---: | --- | --- |
| 1 | Where do internal apps run? (k8s, ECS, App Service, a VM someone maintains) | No approved shared runtime for this prototype was identified. The current path is an internal GitLab project that engineers clone and run locally on their workstations. |
| 2 | Which cloud? AWS, Azure, GCP, on-prem, several? | Azure Gov Cloud |
| 3 | Is there an internal container registry? | No approved internal registry was identified. Docker is not an approved application and cannot be installed on the managed workstation. |
| 4 | How do users log in? (Okta, Entra ID, Ping, SAML, homegrown) | LDAP |
| 5 | Can the app reach the internet? Egress proxy? Allowlist? | The deployed application will not be allowed to reach the public internet. It will need approved internal services or an allowlisted gateway. |
| 6 | Where do secrets come from? (Vault, Secrets Manager, Key Vault) | The current prototype uses a personal environment variable. A production deployment would need an approved secret store or identity-based mechanism. |
| 7 | Who approves a deployment, and what review does it need? | There is no formal deployment approval or review process |
| 8 | Is there an approved internal LLM endpoint already? | Yes |

**What surprised you?**

The fact that we do not have a formalized process for application deployment and
do not currently have an approved way to containerize an application on the
managed workstation.

**What would you have to change about your app to deploy there?**

For the initial prototype, the application would run locally for a small group
of technical experts and be distributed through an internal GitLab project. A
production deployment path and shared runtime still need to be defined. The
public LLM API would need to be replaced with the approved internal LLM gateway,
and any container-based deployment would require an approved alternative to
Docker (possibly an Apptainer solution?).

## Week 2 — production data path

The work version would use production plant-document packages supplied by the
customer. The primary data concern is exposure of sensitive plant-specific
details rather than ordinary PII. All model calls would use the internal
gateway. Customer data-owner approval is required before the documents are
used.

## Week 6 — adversarial-testing limitations

The Week 6 attack work is currently blocked by policy and environment
constraints. Public internet access is unavailable, and the internal LLM API is
not approved for adversarial prompt-injection testing. A classmate's local
Ollama server is also unreachable from this network. Model artifacts may be
downloaded through the approved corporate Nexus repository, but no approved
local model-serving runtime has been identified. Downloading an artifact
therefore does not yet provide an approved inference path.

The Week 6 attack rate, indirect-injection leak rate, tool-description result,
and before/after measurements are **not measured**. No public API, personal key,
unapproved endpoint, or real company data will be used as a workaround. The
remaining requirement is an explicitly approved adversarial-testing endpoint,
runtime, or course-provided lab environment.

The application trust boundary identified so far is:

| Source | Current writer/control | Week 6 implication |
| --- | --- | --- |
| Customer plant documents | Source material is intended to be controlled; the actual corpus owner and ingestion writer still need confirmation | Retrieved text must be treated as data, never instructions |
| Interview notes | Interviewer, with interviewee approval | Notes can still contain instruction-like text and need the same boundary |
| Proposed uprate parameters | Application user | User input must not authorize unsupported impacts or tool actions |
| User-uploaded files | Application user | Uploads are untrusted content and are an indirect-injection surface |

The model is not intended to write files, send data externally, or trigger plant
or business actions. Tool exposure remains a question for the application review;
if tools are available, their descriptions and arguments require separate testing
and deterministic authorization.

---

## Week 1 — what your machine told you

<!--
  Paste the egress probe output from Session 1 here. It is evidence, and it
  frequently disagrees with what people believe about their own network.
-->

The direct egress probe was run from the challenge environment. Every tested
public host was DNS blocked:

| Host | Status | Error |
| --- | --- | --- |
| `pypi.org` | DNS BLOCKED | `gaierror` |
| `files.pythonhosted.org` | DNS BLOCKED | `gaierror` |
| `api.openai.com` | DNS BLOCKED | `gaierror` |
| `cdn.jsdelivr.net` | DNS BLOCKED | `gaierror` |
| `huggingface.co` | DNS BLOCKED | `gaierror` |
| `registry-1.docker.io` | DNS BLOCKED | `gaierror` |
| `github.com` | DNS BLOCKED | `gaierror` |

The package traffic that succeeded during setup used the corporate Nexus proxy,
not direct access to PyPI. The proxy initially failed for the CPU-enabled
PyTorch dependency with `UnknownIssuer` and later returned HTTP 502; a later
`orjson` request timed out. IT reported that the CPU PyTorch repository is not
supported by the current Nexus proxy version. These results show that approved
internal mirrors are required for package installation and that the public
model API, frontend CDN, Hugging Face, Docker registry, and GitHub are not
direct runtime dependencies that can be assumed available.

**Does this match what you were told in the table above?** Yes. The direct
probe confirms the reported no-public-internet constraint. The fact that package
installation can work through Nexus is a documented exception, not open public
egress.

**Package availability constraint:** The corporate Nexus proxy is not currently
serving all packages required by the application environment reliably. A later
`uv sync` request for an `orjson` wheel timed out after repeated retries. The
request also appeared to select a macOS wheel on this Linux x86_64 host, so the
platform selection or proxy metadata needs investigation. As a result, the
Week 1 environment cannot currently be reproduced reliably with `uv sync`. The
application will need either a corrected Nexus proxy, an approved internal
wheelhouse, or pre-approved package artifacts before it can be installed on
this workstation.

---

## Week 9 — the full checklist

<!--
  TC9 extends this same file. Do not start a new one: the point is that the git
  history shows one continuous piece of work from Week 1 to Week 9.
-->

<!-- Week 9 -->
