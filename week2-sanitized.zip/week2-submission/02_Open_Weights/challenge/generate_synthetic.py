"""Generate TC2 synthetic rows through the configured internal LLM gateway.

This runner uses all five golden examples, then reports the counts that matter:
raw rows, unparseable rows, dead combinations, deduplicated rows, and
schema-valid rows.  The generated JSONL and report stay under the gitignored
``use_case/data`` directory.
"""

from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

from pydantic import ValidationError

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "01_Product_Engineering" / "challenge"))

from axes import AXES  # noqa: E402
from schema import Request, Response  # noqa: E402
from helpers import nb  # noqa: E402
from helpers.llm import CallStats, chat  # noqa: E402
from helpers.sdg import dedupe, leak_check  # noqa: E402


TEMPERATURE = 0.35
TOP_P = 0.9
DEDUPE_THRESHOLD = 0.85
PER_COMBINATION = 3

PROMPT = """You generate synthetic examples for the Uprate Impact Mapper.

The examples are fictional. Invent all document identifiers and engineering
details. Do not copy distinctive strings from the seeds. Return exactly one
JSON object per line and no markdown.

The JSON shape is:
{{"input": {{"documents": [str], "proposed_changes": [str],
"missing_information": [str]}}, "output": {{"affected_items": [{{"item": str,
"type": "system|function|component|requirement|document", "reason": str,
"citations": [str], "confidence": "low|medium|high",
"needs_sme_review": true}}], "conclusion": str,
"missing_information": [str], "limitations": [str],
"needs_sme_review": true}}}}

For uncertain but traceable cases, emit low-confidence candidate impacts with
citations and needs_sme_review=true. Do not make an engineering decision.
For the explicit decline profile, emit no affected items and explain the
missing evidence.

Variation profile:
{profile}

Five independent seed examples follow. Make new substantive scenarios, not
paraphrases:
{seeds}

Generate {n} new examples.
"""


def load_seeds(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def combinations() -> list[dict[str, str]]:
    return [
        dict(zip(AXES, values))
        for values in itertools.product(*AXES.values())
    ]


def parse_json_lines(text: str, combo: dict[str, str]) -> tuple[list[dict], int]:
    rows: list[dict] = []
    unparseable = 0
    for line in text.splitlines():
        line = line.strip().strip("`")
        if not line.startswith("{"):
            continue
        try:
            rows.append({**json.loads(line), "_axes": combo})
        except json.JSONDecodeError:
            unparseable += 1
    return rows, unparseable


def valid_row(row: dict) -> bool:
    try:
        request = Request.model_validate(row["input"])
        response = Response.model_validate(row["output"])
        if response.affected_items and any(
            not item.citations for item in response.affected_items
        ):
            return False
        if not request.documents or not request.proposed_changes:
            return False
        return True
    except (KeyError, TypeError, ValidationError):
        return False


def main() -> None:
    cfg = nb.bootstrap(require=("LLM_MODEL", "LLM_API_BASE"))
    golden_path = cfg.use_case / "evals" / "golden.jsonl"
    output_path = cfg.use_case / "data" / "synthetic_v1.jsonl"
    report_path = cfg.use_case / "data" / "synthetic_v1_report.json"
    seeds = load_seeds(golden_path)
    if len(seeds) != 5:
        raise RuntimeError(f"Expected five golden examples, found {len(seeds)}")

    seed_text = "\n".join(json.dumps(seed, ensure_ascii=False) for seed in seeds)
    combos = combinations()
    raw: list[dict] = []
    unparseable = 0
    failed_combos: list[dict] = []
    stats = CallStats()

    for index, combo in enumerate(combos, start=1):
        prompt = PROMPT.format(
            profile="\n".join(f"- {key}: {value}" for key, value in combo.items()),
            seeds=seed_text,
            n=PER_COMBINATION,
        )
        try:
            reply = chat(
                cfg,
                prompt,
                temperature=TEMPERATURE,
                top_p=TOP_P,
                reasoning_effort="none",
                timeout=120.0,
                max_retries=3,
                stats=stats,
            )
        except RuntimeError as exc:
            failed_combos.append({"axes": combo, "error": str(exc)})
            print(
                f"[{index}/{len(combos)}] failed: {combo}\n"
                f"  {type(exc).__name__}: {exc}",
                flush=True,
            )
            continue
        rows, bad = parse_json_lines(reply, combo)
        raw.extend(rows)
        unparseable += bad
        if index % 10 == 0 or index == len(combos):
            print(f"[{index}/{len(combos)}] {stats}", flush=True)

    kept, dropped = dedupe(raw, threshold=DEDUPE_THRESHOLD)
    valid = [row for row in kept if valid_row(row)]
    leaks = leak_check(seeds, valid)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as stream:
        for row in valid:
            stream.write(json.dumps({k: v for k, v in row.items() if not k.startswith("_")}) + "\n")

    report = {
        "settings": {
            "model": cfg.llm_model,
            "temperature": TEMPERATURE,
            "top_p": TOP_P,
            "dedupe_threshold": DEDUPE_THRESHOLD,
            "per_combination": PER_COMBINATION,
            "combinations": len(combos),
        },
        "counts": {
            "generated": len(raw),
            "unparseable": unparseable,
            "dead_combinations": len(failed_combos),
            "after_dedupe": len(kept),
            "schema_valid": len(valid),
        },
        "leaks": leaks,
        "failed_combinations": failed_combos,
        "dropped_examples": [
            {"row": dropped_row, "matched": matched_row}
            for dropped_row, matched_row in dropped[:50]
        ],
        "call_stats": str(stats),
    }
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(report["counts"], indent=2))
    print(f"Wrote {output_path}")
    print(f"Wrote {report_path}")


if __name__ == "__main__":
    main()
