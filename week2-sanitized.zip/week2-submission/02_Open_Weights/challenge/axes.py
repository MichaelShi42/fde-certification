"""Variation axes for the Uprate Impact Mapper synthetic dataset.

These axes describe coverage decisions for TC2.  They intentionally include
an evidence-poor combination that teaches the system to decline rather than
invent an engineering assessment.
"""

AXES: dict[str, list[str]] = {
    "source_extraction_quality": [
        "native text",
        "readable OCR",
        "partial OCR",
    ],
    "referenced_document_availability": [
        "complete reference chain",
        "shallow chain available but deeper references missing",
        "system-specific documents absent",
        "direct references missing",
        "references ambiguous or inconsistent",
    ],
    "assessment_basis": [
        "defined acceptance criterion and operating limit",
        "acceptance criterion or operating limit missing",
    ],
    "changed_parameter": [
        "thermal",
        "flow",
        "pressure",
        "electrical load",
        "licensing-basis change",
        "no defined parameter change",
    ],
}


DECLINE_PROFILE = {
    "referenced_document_availability": "system-specific documents absent",
    "assessment_basis": "acceptance criterion or operating limit missing",
    "changed_parameter": "no defined parameter change",
}
