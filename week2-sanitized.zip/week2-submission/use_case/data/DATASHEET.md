# Datasheet

<!-- Written in TC2, alongside your synthetic data. This file is committed; the
     data itself is not. -->

## What this data is

**Data type:** Prototyping data. Synthetic inputs and outputs exercise the pipeline;
the candidate impacts have not been accepted as engineering ground truth by an SME.
**Generated on:** 2026-10-20
**Generated from:** The Week 1 Pydantic schema, the written variation-axis profiles,
and five hand-written golden examples. No real production records were used.
**Rows:** 450 schema-valid rows

**Generation settings and counts:** 180 axis combinations, three requested rows
per combination, temperature `0.35`, top-p `0.9`, and character n-gram dedupe
threshold `0.85`. The run produced 450 parseable rows, 90 unparseable outputs,
0 dead combinations, 450 rows after deduplication, and 450 schema-valid rows.
The approved internal model gateway reported 369,985 total tokens for
180 calls (192,486 prompt and 177,499 completion tokens), with 897.8 seconds
elapsed.

## Variation axes

<!-- What you varied to get coverage. These axes are specific to the uprate-impact
     assessment and include an explicit abstention case. -->

| Axis | Values | Expected handling |
| --- | --- | --- |
| Source extraction quality | Native text; readable OCR; partial OCR | Identify the exact unreadable figure label when possible; otherwise report the page and general area. Never invent missing figures, statistics, or engineering data. SME review is always required. A fully unusable single-system sketch was removed after review because the project engineer said that input is extremely unlikely in customer document packages. |
| Referenced-document availability | Complete reference chain; shallow chain available but deeper references missing; system-specific documents absent; direct references missing; references ambiguous or inconsistent | Use available evidence when it supports a traceable candidate. Missing or ambiguous references lower confidence and require SME review; absence of system-specific documents contributes to the decline case. |
| Assessment basis | Defined acceptance criterion and operating limit; acceptance criterion or operating limit missing | When the basis is missing, emit only hypothetical candidate impacts when the other minimum evidence exists, and explicitly state that the result is pending actual operating parameters and acceptance criteria. SME review is always required. |
| Changed parameter | Thermal; flow; pressure; electrical load; licensing-basis change; no defined parameter change | A flow change should test whether downstream component qualification, such as valve qualification, is affected. A missing parameter is part of the decline case. |

**Mandatory decline combination:** no defined parameter change, no system-specific
documents, and no acceptance criterion or operating limit. A case with a defined
change and traceable system evidence may still emit a low-confidence candidate
impact for SME validation rather than declining.

**Reviewer-informed coverage gap:** the project engineer expects evaluations to
contain roughly 100 or more plant documents, while this version does not yet vary
document-package size. That is a follow-up axis for the next generation rather
than a claim this dataset currently covers.

## What it can validate

This data can validate that the prototype can:

- ingest and emit the Week 1 JSON contract;
- exercise the four selected variation axes, including flow-related component
  qualification candidates;
- preserve document citations and SME-review flags on candidate impacts; and
- decline the explicit no-parameter, no-system-documentation, and no-acceptance-
  basis case.

## What it cannot validate

It cannot validate whether a candidate impact is technically correct for a real
nuclear system. The rows also cannot establish how frequently each parameter
change or document-quality condition occurs in real uprate evaluations. Finally,
they cannot reveal failure modes, document structures, or system relationships
that are absent from the four selected axes and the five seed examples.

## What it must never be compared against

These rows must never be compared as though they were engineering ground truth.
The relevant ground truth would be SME-accepted impact evaluations against
approved plant documentation; those evaluations are not included here.

The five golden examples were written independently of real production cases and
remain disjoint from prompt-tuning, retrieval, and model-training material.
The project engineer reviewing the dataset said that leakage of the synthetic
language would be low concern because it is vague; that does not establish that
production plant-specific documents may be shared or sent to an unapproved
endpoint.

## Leakage check

- [x] No real record was used as a seed.
- [x] No real entity names, IDs, or identifiers appear.
- [x] No distinctive internal formats that would identify the firm.
- [x] Rare categories were generated, not copied.

**Manual review:** Fifty rows from the regenerated dataset were read by hand. No
row was removed. No real names, companies, identifiers, distinctive internal
formats, or other leakage indicators were found, and no quality issue was found
that required removing a row.
