"""Collect 50 deliberately varied endpoint traces from the golden cases.

The cases are generated robustness probes, not claims about natural production
frequency. They cover boundary values, missing evidence, distractors,
contradictions, paraphrases, and plausible unsupported additions. Review the
resulting file by hand before using it for judge calibration.

Usage:
    EVAL_URL=http://127.0.0.1:7860/gradio_api/call/assess_uprate_impact \
      python use_case/evals/collect_traces.py
"""

from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from use_case.evals.run import call_endpoint


def load_goldens() -> list[dict]:
    return [
        json.loads(line)
        for line in (ROOT / "use_case/evals/golden.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    ]


def variations(case: dict, count: int) -> list[str]:
    """Create valid requests across varied, labeled robustness conditions."""
    base = json.loads(case["input"])
    output: list[str] = []
    modes = (
        "baseline",
        "near_limit",
        "at_limit",
        "over_limit",
        "missing_acceptance",
        "missing_mapping",
        "distractor",
        "contradiction",
        "paraphrase",
        "extra_change",
    )
    for index in range(count):
        request = copy.deepcopy(base)
        changes = request["proposed_changes"]
        documents = request["documents"]
        mode = modes[index % len(modes)]

        for change in changes:
            if mode == "paraphrase":
                change["description"] = (
                    f"Assess the documented plant effects of {change['description'].lower()}"
                )
            elif mode == "extra_change":
                change["description"] = (
                    f"{change['description']} Also assess the connected surveillance basis."
                )
            else:
                change["description"] = f"{change['description']} ({mode} probe)"

            baseline = change.get("baseline")
            proposed = change.get("proposed")
            limit = change.get("acceptance_limit")
            if baseline is not None and proposed is not None:
                if mode == "near_limit" and limit is not None:
                    change["proposed"] = limit - max(1, abs(limit - baseline) // 20)
                elif mode == "at_limit" and limit is not None:
                    change["proposed"] = limit
                elif mode == "over_limit" and limit is not None:
                    change["proposed"] = limit + max(1, abs(limit - baseline) // 20)
                elif mode == "extra_change":
                    change["proposed"] = proposed + max(1, abs(proposed - baseline) // 10)

        if mode == "missing_acceptance":
            request["missing_information"] = ["Applicable acceptance criteria"]
        elif mode == "missing_mapping":
            request["missing_information"] = ["Requirement-to-component mapping"]
        elif mode == "distractor":
            request["documents"].append(
                {
                    "id": f"DOC-DIST-{index + 1}",
                    "title": "Unrelated planning memorandum",
                    "text": "This memorandum discusses project scheduling only and contains no approved engineering impact conclusion.",
                }
            )
        elif mode == "contradiction":
            request["documents"].append(
                {
                    "id": f"DOC-CONFLICT-{index + 1}",
                    "title": "Unresolved preliminary calculation",
                    "text": "Preliminary values differ from the controlled operating records. The discrepancy is unresolved and must not be treated as an approved limit.",
                }
            )
        elif mode == "extra_change":
            request["missing_information"] = ["Approved surveillance test point"]

        if mode == "baseline" and documents:
            # Add no evidence; this is the unmodified control case.
            pass
        elif mode == "paraphrase":
            for document in documents:
                document["text"] += (
                    " Section 6.2 — Instrument record. Flow indication was recorded during the reference operating condition."
                )

        output.append(json.dumps(request, ensure_ascii=False))
    return output


def main() -> None:
    cases = load_goldens()
    # Spread fifty probes across however many golden families are present.
    base_count, remainder = divmod(50, len(cases))
    requests = [
        request
        for position, case in enumerate(cases)
        for request in variations(case, base_count + (position < remainder))
    ]
    target = Path(
        os.environ.get("TRACE_OUTPUT", str(ROOT / "use_case/data/week4_traces.jsonl"))
    )
    target.parent.mkdir(parents=True, exist_ok=True)
    # Use a per-process temporary name so a stale NFS handle from an interrupted
    # run cannot be reused on the next collection attempt.
    temporary = target.with_name(f".{target.name}.{os.getpid()}.tmp")

    errors = 0
    with temporary.open("w", encoding="utf-8") as handle:
        for index, request in enumerate(requests, start=1):
            try:
                actual = call_endpoint(request)
                json.loads(actual)  # reject truncated/non-JSON endpoint responses
                row = {"index": index, "input": request, "actual": actual}
            except Exception as exc:
                errors += 1
                row = {
                    "index": index,
                    "input": request,
                    "actual": "",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
            print(f"{index}/50", flush=True)

    if errors:
        temporary.unlink(missing_ok=True)
        raise RuntimeError(
            f"{errors} endpoint calls failed; no valid 50-trace set was collected. "
            "Start the service and inspect the endpoint URL before retrying."
        )
    temporary.replace(target)
    print(f"Wrote {len(requests)} traces to {target}")


if __name__ == "__main__":
    main()
