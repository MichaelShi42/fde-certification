"""Week 4 scenario decision.

The current uprate endpoint is single-turn and has no conversation state or
write-capable tools. Multi-turn trajectory evaluation is therefore optional
and intentionally skipped; the decision is recorded here so later weeks do
not mistake the omission for an unexamined gap.
"""

SCENARIOS = []
