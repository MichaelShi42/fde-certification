"""Check the calibrated judge against the twenty SME-reviewed traces."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from helpers import nb
from helpers.judge import Judge
from use_case.evals.harness import JUDGE_RUBRIC


EVALS = ROOT / "use_case" / "evals"
TRACES = ROOT / "use_case" / "data" / "week4_traces.jsonl"


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> None:
    traces = {row["index"]: row for row in read_jsonl(TRACES)}
    reviews = read_jsonl(EVALS / "human_scores.jsonl")
    goldens = read_jsonl(EVALS / "golden.jsonl")

    judge = Judge(nb.bootstrap(), rubric=JUDGE_RUBRIC)
    calibration = judge.calibrate(goldens)
    print(calibration)
    if not calibration.passed:
        raise SystemExit("Judge calibration failed; agreement is not meaningful.")

    matches = 0
    human_passes = 0
    judge_passes = 0
    for review in reviews:
        trace = traces[review["trace_index"]]
        case = {"input": trace["input"], "output": review["expected"]}
        score = judge.score(trace["actual"], case)
        judge_pass = score >= 0.5
        human_pass = bool(review["pass"])
        matches += judge_pass == human_pass
        human_passes += human_pass
        judge_passes += judge_pass
        print(
            f"trace {review['trace_index']:>2}: human={'pass' if human_pass else 'fail':>4} "
            f"judge={score:.2f} ({'pass' if judge_pass else 'fail'})"
        )

    n = len(reviews)
    agreement = matches / n if n else 0.0
    chance_floor = max(human_passes, n - human_passes) / n if n else 0.0
    print(f"agreement: {agreement:.3f} ({matches}/{n})")
    print(f"human pass rate: {human_passes / n:.3f}")
    print(f"judge pass rate: {judge_passes / n:.3f}")
    print(f"majority-class chance floor: {chance_floor:.3f}")


if __name__ == "__main__":
    main()
