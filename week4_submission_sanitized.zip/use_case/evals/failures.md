# Week 4 failure taxonomy

This taxonomy is based on SME review of 20 selected endpoint traces. The current
50-row trace file contains generated robustness probes, not 50 independent real
traces. Eight of the 20 reviewed probes were classified as failures. Fifty
independent real or appropriately anonymized traces will be added in a later
iteration before making natural failure-rate claims.

| Rank | Failure mode | Reviewed count | Reviewed traces | Scorer |
| ---: | --- | ---: | --- | --- |
| 1 | Impact list asserted despite insufficient controlled evidence | 2 | 19, 22 | judge / SME review |
| 2 | Impact list asserted from unreadable OCR or figure evidence | 5 | 27, 29, 30, 32, 34 | judge / SME review |
| 3 | Unresolved preliminary calculation treated as a controlled limit | 1 | 50 | judge / SME review |

These are review-sample counts, not production failure rates. The current
deterministic scorers check response shape, outcome category, and citation
membership; the failure modes above primarily test whether a response makes a
substantive engineering claim that the supplied evidence cannot support. That
is why the calibrated judge and SME review remain necessary. Add the 50 real
traces and revise the counts before using this taxonomy to describe natural
failure frequency.
