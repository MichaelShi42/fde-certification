"""Week 4 evaluation harness for the uprate-impact endpoint.

The domain-specific failure taxonomy and judge rubric still belong to the
student.  These conservative scorers cover only the contract already present
in the Week 1 goldens and schema.
"""

from __future__ import annotations

import json
import random
from typing import Any


OUTCOMES = {
    "candidate_impacts",
    "no_impact_identified",
    "insufficient_evidence",
    "declined",
}


def parse_response(actual: str) -> dict[str, Any] | None:
    """Return a response object, or None when the endpoint returned bad JSON."""
    try:
        value = json.loads(actual)
    except (TypeError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def valid_response(actual: str, _case: dict) -> float:
    """Catches malformed output (failures.md line 3)."""
    response = parse_response(actual)
    if response is None or response.get("outcome") not in OUTCOMES:
        return 0.0
    required = {"affected_items", "conclusion", "missing_information", "limitations"}
    return float(required.issubset(response))


def outcome_match(actual: str, case: dict) -> float:
    """Catches wrong decision categories (failures.md line 1)."""
    response = parse_response(actual)
    expected = parse_response(case.get("output", ""))
    if response is None or expected is None:
        return 0.0
    return float(response.get("outcome") == expected.get("outcome"))


def traceability(actual: str, case: dict) -> float:
    """Catches missing or fabricated citations (failures.md line 2)."""
    response = parse_response(actual)
    if response is None:
        return 0.0
    if response.get("outcome") != "candidate_impacts":
        return 1.0
    items = response.get("affected_items")
    if not isinstance(items, list) or not items:
        return 0.0
    document_ids = {
        document.get("id")
        for document in _request(case).get("documents", [])
        if isinstance(document, dict)
    }
    cited = {
        citation.get("document_id")
        for item in items
        if isinstance(item, dict)
        for citation in item.get("citations", [])
        if isinstance(citation, dict)
    }
    return float(bool(cited) and cited.issubset(document_ids))


def _request(case: dict) -> dict[str, Any]:
    try:
        value = json.loads(case.get("input", "{}"))
    except (TypeError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


SCORERS = {
    "valid_response": valid_response,
    "outcome_match": outcome_match,
    "traceability": traceability,
}


JUDGE_RUBRIC = """You are an extended-power-uprate engineering reviewer.
The text after "Answer to score" is the candidate answer. The JSON after
"Question" contains the supplied documents and proposed change; it is the
evidence to use, not a missing input. The JSON after "Reference answer" is the
domain-expert answer for comparison.

Question:
{input}

Reference answer:
{expected}

Answer to score:
{actual}

Score 1 when the candidate's outcome is appropriate, its claimed impacts are
supported by the supplied documents, and it does not invent plant facts. A
cautious insufficient_evidence or declined answer earns 1 when the records do
not support a determination. Score 0 for a wrong outcome, unsupported impact,
fabricated citation, or malformed/incomplete answer. Wording differences do
not matter. Return JSON only: {{\"score\": 0 or 1, \"why\": \"one sentence\"}}."""


def bootstrap_ci(values: list[float], *, seed: int = 41, rounds: int = 4000) -> tuple[float, float]:
    """Return a percentile bootstrap interval for a bounded score list."""
    if not values:
        return 0.0, 0.0
    rng = random.Random(seed)
    means = [
        sum(rng.choice(values) for _ in values) / len(values)
        for _ in range(rounds)
    ]
    means.sort()
    return means[int(rounds * 0.025)], means[int(rounds * 0.975)]


def synthetic_failures(cases: list[dict]) -> list[dict]:
    """Create labelled, deterministic corruptions of the hand-written goldens.

    These are deliberately test cases, not claims about natural failure rates.
    The natural count must come from the user's 50-trace review.
    """
    generated: list[dict] = []
    for case in cases:
        expected = parse_response(case.get("output", ""))
        if expected is None:
            continue
        mutations = []
        if expected.get("outcome") != "declined":
            mutations.append(("wrong_outcome", {**expected, "outcome": "declined"}))
        if expected.get("outcome") == "candidate_impacts":
            mutations.extend(
                [
                    (
                        "missing_citations",
                        {
                            **expected,
                            "affected_items": [
                                {**item, "citations": []}
                                for item in expected.get("affected_items", [])
                            ],
                        },
                    ),
                    (
                        "unsupported_item",
                        {
                            **expected,
                            "affected_items": [
                                *expected.get("affected_items", []),
                                {
                                    "item": "Unsupported fabricated system",
                                    "type": "system",
                                    "reason": "Synthetic unsupported addition.",
                                    "citations": [],
                                    "confidence": "high",
                                    "needs_sme_review": True,
                                },
                            ],
                        },
                    ),
                ]
            )
        for failure_mode, actual in mutations:
            generated.append(
                {
                    "input": case.get("input", ""),
                    "expected": case.get("output", ""),
                    "actual": json.dumps(actual, ensure_ascii=False),
                    "failure_mode": failure_mode,
                }
            )
    return generated
