# Evals

## `golden.jsonl`

The five core examples plus one public ACRS-derived example are written by
hand. They are not generated.

Each line is one object:

```json
{"input": "...", "output": "...", "why": "what makes this the right answer"}
```

`input` and `output` are always strings. For structured contracts, store their
JSON representation in those strings; do not use objects as dictionary keys in
an oracle. The provisional recall benchmark follows the same convention.

The `why` field is the one that earns its keep. In Week 4 you calibrate an
LLM judge against these, and "why" is what you calibrate it on.

### Why you write these by hand

They are the fixed point of the whole cohort. A model-generated example encodes
what the model already does; a hand-written one encodes what *you* would accept,
which is the only thing worth measuring against.

| Week | What uses this file |
| --- | --- |
| 2 | Seeds for synthetic data generation — your variation axes come from these. |
| 4 | The eval harness scores against them, and the judge is calibrated on them. |
| 6 | Injection regressions get added alongside them. |
| 8 | **The bar.** A fine-tuned open model has to pass the same harness the closed one did. |

Get them wrong now and every number for the next nine weeks is measuring the
wrong thing.

### Writing good ones

- Use **real inputs** from your work, with names and identifiers removed.
- Write the output you would **actually accept**, not an idealized one.
- Include at least one **edge case** and one where the right answer is *"I don't
  know"* or *"escalate this"*. A system that never declines is not calibrated.
- Keep them short enough to read in full during review.

## Impact recall benchmark

`daec_acrs_recall_benchmark.json` is a public, provisional answer key derived
from an ACRS review. Recall is the number of expected technical impacts that
the response identifies, divided by the number of expected impacts. Equivalent
wording counts; unsupported extra items do not. Replace or supplement this case
with one sanitized past evaluation and an accepted SME answer key before making
quality claims.

## Week 4 submission record

This is based on **real SME feedback**. The committed baseline is now produced
by the live Week 3 endpoint over the reviewed cases.

| System | valid response | outcome match | traceability | LLM judge |
| --- | ---: | ---: | ---: | ---: |
| Echo | 0.00 | 0.00 | 1.00 | 0.00 |
| Live Week 3 endpoint baseline | 1.00 | 0.50 | 1.00 | 0.67 |
| Oracle | 1.00 | 1.00 | 1.00 | 1.00 |

The headline is `outcome_match = 0.50`, n=6, bootstrap 95% CI [0.17, 0.83].
`harness.compare()` against the saved file reports PASS. The calibrated LLM
judge scored the live endpoint at `0.67`; its separation was 1.00 on the
accepted cases and 0.00 on the known-wrong cases. Human calibration examples
are in `human_scores.jsonl`; the taxonomy is in `failures.md`. On the 20
SME-reviewed traces, judge/human agreement was `0.80` (16/20), above the
majority-class chance floor of `0.60`.

The selected 20 SME-reviewed traces contained 8 failures. Generated failures in
`synthetic.jsonl`: 8. Detection on the generated set:

| Failure mode | Cases | valid response | outcome match | traceability |
| --- | ---: | ---: | ---: | ---: |
| wrong outcome | 4 | 1.00 | 0.00 | 1.00 |
| missing citations | 2 | 1.00 | 1.00 | 0.00 |
| unsupported item | 2 | 1.00 | 1.00 | 1.00 |

LLM-judge separation is available and passed calibration. It is reported beside
the deterministic headline rather than replacing it.

The endpoint is single-turn and read-only, so multi-turn scenarios are not
applicable; `scenarios.py` records that decision.

## Bring it to work

- **Data:** Fifty sanitized historical uprate-impact assessments reviewed by an extended-power-uprate SME; approval is required before export.
- **Model/endpoint:** The internal Azure Gov LLM gateway and the same Gradio endpoint; judge calls remain inside the approved network. The completed run made 30 judge calls: 12 for calibration and 18 for the echo, oracle, and live endpoint reports.
- **Access/approval:** Read access to controlled engineering records, SME answer-key approval, and platform approval for the internal service and model gateway.
