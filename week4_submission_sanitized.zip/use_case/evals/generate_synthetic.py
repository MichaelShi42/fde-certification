"""Generate labelled failure cases from the Week 1 golden examples."""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from use_case.evals.harness import synthetic_failures


def main() -> None:
    source = ROOT / "use_case/evals/golden.jsonl"
    target = ROOT / "use_case/evals/synthetic.jsonl"
    cases = [
        json.loads(line)
        for line in source.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    failures = synthetic_failures(cases)
    target.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in failures),
        encoding="utf-8",
    )
    print(f"wrote {len(failures)} labelled failures to {target}")


if __name__ == "__main__":
    main()
