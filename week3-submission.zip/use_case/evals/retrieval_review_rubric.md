# Retrieval answer-review rubric

This rubric is the review sheet for the model-backed Week 3 run. The repository
contains a simulated SME review in `retrieval_review.jsonl` so the evaluation
can be reproduced without claiming that a real systems engineer approved it.
Replace the simulated reviewer with a real SME before treating the results as
engineering evidence.

## Per-question review

For every question, record:

- `answer_terms`: the words, values, or entities that a correct answer must
  contain;
- `required_sources`: the record IDs that must be cited;
- `decline_expected`: whether the current corpus is insufficient;
- `reviewer`: the SME role, not a personal name;
- `notes`: corrections to the label or answer.

## Pass rule

- A supported question passes only when all required answer terms are present
  and every required source is cited.
- A multi-record question fails if any required record is missing, even if the
  answer sounds plausible.
- A decline question passes only when the answer explicitly states that the
  available evidence is insufficient and does not invent a value, component,
  or setpoint.
- A citation is valid only when the cited ID was retrieved and supports the
  claim being made.

## Current status

The ten graded questions have simulated answer terms, required sources, and
decline decisions in `retrieval_review.jsonl`. The six systems-engineer
follow-up questions remain expected declines against the current synthetic
corpus because it lacks the requested capacity change tables, drawings, setpoint register,
and scope package. Re-label them after the multimodal corpus is added.
