# Project charter

<!--
  Fill this in during TC1, from your Getting to Concreteness worksheet.
  Every week's Session 2 notebook reads this file and stops if it is still the
  template. That is on purpose.
-->

**Department:** industrial Engineering / facility Systems Engineering

**Working title:** capacity change Impact Mapper

---

## The problem

**Who has it?** One real role, not a department.

System engineers who evaluate industrial facility systems, typically engineers
with 5–10+ years of industry experience. Approximately 5–25 people may
participate across the work.

**What are they trying to do?**

Determine which systems, functions, components, requirements, and supporting
documents may be affected by a proposed capacity change.

**How do they handle it today?**

They read and compare facility documentation such as the USAR, facility technical
specifications, and technical requirements manuals. They also interview facility
engineers to understand relationships and reason about which elements of each
system are affected by the proposed change.

**What does that cost — time, money, risk, or relationships?**

The evaluation requires approximately 1,000–2,000 person-hours per system.
Without improvement, the organization may be unable to scale to roughly 20
system evaluations over the next five years, leaving engineers overworked,
reducing profitability, and increasing the risk of unhappy or lost customers.

**The problem in one sentence. No solution in it.**

System engineers spend substantial time manually searching and reasoning across
facility documentation to identify the systems, functions, components, and
requirements affected by a proposed capacity change.

---

## Success

**What does the new world look like for that person?**

Engineers can begin an evaluation with a traceable candidate-impact list rather
than starting with a manual search of hundreds of documents. The firm can use
its limited subject-matter expertise across more projects while engineers still
review and approve the findings.

**How would the firm measure it? Which numbers should move?**

Reduce the manual effort required per system evaluation, increase the number of
capacity change evaluations the team can support, and maintain reviewable evidence for
each proposed impact. I would also say, in this case, it might be difficult to point to
one concrete number as one that can meaningfully quantify system impact.

---

## The first product

**Your solution in one sentence.**

An LLM-based application that helps system engineers identify and review the
facility elements affected by a proposed capacity change.

**Input → Output.** Be specific enough that someone could build it wrong and you
would notice.

| | |
| --- | --- |
| **In** | A selected set of anonymized facility design-basis documents and relevant interview notes, plus one or more proposed power-capacity change parameter changes. |
| **Out** | A traceable list of potentially affected systems, functions, components, requirements, and source documents, with a rationale, source citation where available, confidence indication, and subject-matter-expert review flag. |

---

## Decisions made later

<!--
  Amended as the cohort goes. Keep the reasoning, not just the choice — Week 5
  asks you to defend your architecture against the options you rejected, and
  Week 10's handoff doc is largely this section.
-->

| Week | Decision | Why, and what you rejected |
| --- | --- | --- |
| 3 | BM25 retrieval with chat-model reranking; Agentic RAG and direct corpus interaction were rejected because they had weaker source-grounding proxies and higher call/evidence costs. Dense or hybrid retrieval was not available without an approved embedding endpoint. Re-run with SME-reviewed answer terms and a real decline rubric before treating this as a production-quality result. |
| 5 | Agent architecture | <!-- TC5 --> |
| 8 | Model | <!-- TC8 --> |
