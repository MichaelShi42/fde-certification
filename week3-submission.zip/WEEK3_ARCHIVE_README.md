# Week 3 relevant files from the original week 3 branch

This archive is based on `mshi-week-3` versus `mshi-week-2`. It includes the changed application code, supporting helpers/scripts, and Week 3 project evaluation artifacts. Teaching-only notebooks and their example corpus are intentionally omitted. Text was sanitized for company/domain identifiers, infrastructure details, private addresses, credentials, and proprietary terms.
