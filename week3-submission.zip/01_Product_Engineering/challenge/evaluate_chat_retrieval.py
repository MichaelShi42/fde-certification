"""Measure three non-embedding retrieval approaches with the internal chat model."""

from __future__ import annotations

import argparse
import json
import re
import time
from pathlib import Path

from litellm import completion

from retrieval import BM25Retriever, Record, load_records


DECLINE_MARKERS = ("insufficient", "cannot determine", "not enough", "unable", "decline", "not provided")


def model_call(messages: list[dict], tools: list[dict] | None = None) -> object:
    kwargs = {"model": __import__("os").environ["LLM_MODEL"], "messages": messages}
    if __import__("os").environ.get("LLM_API_BASE"):
        kwargs["api_base"] = __import__("os").environ["LLM_API_BASE"]
    if __import__("os").environ.get("LLM_EXTRA_HEADERS"):
        kwargs["extra_headers"] = json.loads(__import__("os").environ["LLM_EXTRA_HEADERS"])
    if tools:
        kwargs["tools"] = tools
    return completion(**kwargs).choices[0].message


def schema(name: str, description: str, properties: dict, required: list[str] | None = None) -> dict:
    return {"type": "function", "function": {"name": name, "description": description,
            "parameters": {"type": "object", "properties": properties, "required": required or []}}}


def records_by_source(records: list[Record]) -> dict[str, Record]:
    return {record.source: record for record in records}


def tool_sets(records: list[Record], bm25: BM25Retriever):
    by_source = records_by_source(records)
    chunks = [{"source": record.source, "text": record.text} for record in records]

    def search_chunks(query: str, k: int = 5) -> str:
        hits = bm25.search(query, k=max(1, min(k, 8)))
        return "\n\n---\n\n".join(f"[{hit.source}]\n{hit.text[:1800]}" for hit in hits)

    def list_documents() -> str:
        return "\n".join(f"{record.source}: {record.title}" for record in records)

    def search_documents(query: str) -> str:
        terms = set(re.findall(r"[a-z0-9]+", query.lower()))
        rows = []
        for record in records:
            text_terms = set(re.findall(r"[a-z0-9]+", record.text.lower()))
            if terms & text_terms:
                rows.append(f"[{record.source}] {record.title}")
        return "\n".join(rows[:40]) or "(no matching documents)"

    def read_document(source: str) -> str:
        record = by_source.get(source)
        return f"[{source}]\n{record.text[:12000]}" if record else "(unknown source)"

    return (
        {"search_chunks": search_chunks},
        [schema("search_chunks", "Search ranked document evidence.", {"query": {"type": "string"}, "k": {"type": "integer"}}, ["query"])],
        {"list_documents": list_documents, "search_documents": search_documents, "read_document": read_document},
        [
            schema("list_documents", "List stable document IDs and titles.", {}),
            schema("search_documents", "Search document titles and contents.", {"query": {"type": "string"}}, ["query"]),
            schema("read_document", "Read one document by stable source ID.", {"source": {"type": "string"}}, ["source"]),
        ],
    )


def run_agent(question: str, tools: list[dict], functions: dict, max_turns: int = 6) -> dict:
    system = "Answer only from tool evidence. Cite source IDs. If evidence is insufficient, say so clearly."
    messages = [{"role": "system", "content": system}, {"role": "user", "content": question}]
    trace, evidence_chars = [], 0
    started = time.perf_counter()
    for _ in range(max_turns):
        message = model_call(messages, tools)
        calls = getattr(message, "tool_calls", None) or []
        if not calls:
            return {"answer": (getattr(message, "content", "") or "").strip(), "trace": trace,
                    "evidence_chars": evidence_chars, "latency_seconds": time.perf_counter() - started,
                    "calls": len(trace), "stop_reason": "answer"}
        shaped = []
        messages.append({"role": "assistant", "content": getattr(message, "content", "") or "", "tool_calls": []})
        for call in calls:
            name = call.function.name
            args = json.loads(call.function.arguments or "{}")
            result = str(functions[name](**args))
            shaped.append({"id": call.id, "type": "function", "function": {"name": name, "arguments": call.function.arguments}})
            # Only treat a bracketed line at the start of an evidence block as
            # provenance.  Document text can contain JSON lists and citations;
            # collecting every bracketed fragment pollutes the source column.
            evidence_sources = re.findall(r"(?m)^\[([A-Z0-9][A-Z0-9-]*)\]\s*$", result)
            trace.append({"tool": name, "args": args, "chars": len(result),
                          "sources": evidence_sources})
            evidence_chars += len(result)
            messages.append({"role": "tool", "tool_call_id": call.id, "content": result})
        messages[-len(shaped) - 1]["tool_calls"] = shaped
    return {"answer": "(maximum investigation turns reached)", "trace": trace,
            "evidence_chars": evidence_chars, "latency_seconds": time.perf_counter() - started,
            "calls": len(trace), "stop_reason": "max_turns"}


def reranked_answer(question: str, hits: list, k: int = 5) -> dict:
    started = time.perf_counter()
    candidates = "\n\n---\n\n".join(f"[{hit.source}]\n{hit.text[:1600]}" for hit in hits)
    ranking_message = [{"role": "system", "content": "Return only a JSON array of the best source IDs."},
                       {"role": "user", "content": f"Rank the best sources for this question. Question: {question}\nCandidates:\n{candidates}"}]
    ranked_text = getattr(model_call(ranking_message), "content", "") or "[]"
    match = re.search(r"\[[^\]]*\]", ranked_text, re.S)
    try:
        ranked_ids = json.loads(match.group(0)) if match else []
    except json.JSONDecodeError:
        ranked_ids = []
    by_source = {hit.source: hit for hit in hits}
    selected = [by_source[source] for source in ranked_ids if source in by_source][:k]
    if not selected:
        selected = hits[:k]
    evidence = "\n\n---\n\n".join(f"[{hit.source}]\n{hit.text[:1800]}" for hit in selected)
    answer_message = [{"role": "system", "content": "Answer only from the evidence. Cite source IDs and decline if insufficient."},
                      {"role": "user", "content": f"Question: {question}\nEvidence:\n{evidence}"}]
    answer = (getattr(model_call(answer_message), "content", "") or "").strip()
    return {"answer": answer, "trace": [{"tool": "bm25", "args": {"k": len(hits)}, "chars": sum(len(hit.text) for hit in hits)},
                                         {"tool": "rerank", "args": {"k": k}, "chars": len(ranked_text)}],
            "evidence_chars": sum(len(hit.text) for hit in selected),
            "latency_seconds": time.perf_counter() - started, "calls": 2, "stop_reason": "answer",
            "selected_sources": [hit.source for hit in selected]}


def score(case: dict, result: dict, retrieved_sources: list[str], review: dict | None = None) -> dict:
    answer = result["answer"].lower()
    gold = set(case.get("gold", []))
    if case["kind"] == "decline":
        decline_correct = any(marker in answer for marker in DECLINE_MARKERS)
        passed = decline_correct
        cited = None
        recall = None
        answer_quality = decline_correct if review else None
    else:
        cited = gold.issubset(set(retrieved_sources))
        recall = len(gold & set(retrieved_sources)) / len(gold) if gold else None
        passed = cited
        answer_terms = [str(term).lower() for term in (review or {}).get("answer_terms", [])]
        required_sources = set((review or {}).get("required_sources", case.get("gold", [])))
        answer_citations = set(re.findall(r"\[([^\]]+)\]", result["answer"]))
        answer_citations.update(
            source for source in required_sources if source.lower() in answer
        )
        terms_present = all(term in answer for term in answer_terms)
        sources_cited = required_sources.issubset(answer_citations)
        answer_quality = terms_present and sources_cited if review else None
        decline_correct = None
    return {
        "pass": passed,
        "answer_quality": answer_quality,
        "decline_correct": decline_correct,
        "cited": cited,
        "source_recall": recall,
        "retrieved_sources": retrieved_sources,
        **result,
    }


def markdown_report(rows: list[dict]) -> str:
    """Render the JSONL run output as an auditable per-question report."""

    lines = [
        "# Detailed Week 3 retrieval run",
        "",
        "Generated from the model-backed evaluation runner. Review the answer and",
        "decline criteria before using the pass rate as a production claim.",
        "",
        "| Technique | Question | Kind | Pass | Answer quality | Decline correct | Cited | Calls | Evidence read | Latency (s) | Sources |",
        "| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |",
    ]
    for row in rows:
        question = str(row.get("question", "")).replace("|", "\\|").replace("\n", " ")
        sources = ", ".join(row.get("retrieved_sources", []))
        lines.append(
            f"| {row['technique']} | {question} | {row.get('kind', '')} | "
            f"{row.get('pass', False)} | {row.get('answer_quality')} | "
            f"{row.get('decline_correct')} | {row.get('cited')} | {row.get('calls', 0)} | "
            f"{row.get('evidence_chars', 0)} | {row.get('latency_seconds', 0):.3f} | {sources} |"
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus", type=Path, required=True)
    parser.add_argument("--evals", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path)
    parser.add_argument(
        "--review",
        type=Path,
        help="Optional JSONL review keyed by question, with answer_terms and required_sources",
    )
    args = parser.parse_args()
    records = load_records(args.corpus)
    bm25 = BM25Retriever(records)
    rag_funcs, rag_tools, dci_funcs, dci_tools = tool_sets(records, bm25)
    cases = [json.loads(line) for line in args.evals.read_text(encoding="utf-8").splitlines() if line.strip()]
    reviews = {}
    if args.review:
        reviews = {
            row["question"]: row
            for row in (
                json.loads(line)
                for line in args.review.read_text(encoding="utf-8").splitlines()
                if line.strip()
            )
        }
    rows = []
    for case in cases:
        rag = run_agent(case["question"], rag_tools, rag_funcs)
        rag_sources = [step["args"].get("source") for step in rag["trace"] if step["tool"] == "read_document"]
        rag_sources += [source for step in rag["trace"] if step["tool"] == "search_chunks" for source in step.get("sources", [])]
        review = reviews.get(case["question"])
        rows.append({"question": case["question"], "kind": case["kind"], "technique": "agentic_rag", **score(case, rag, list(dict.fromkeys(rag_sources)), review)})
        dci = run_agent(case["question"], dci_tools, dci_funcs)
        dci_sources = [step["args"].get("source") for step in dci["trace"] if step["tool"] == "read_document"]
        rows.append({"question": case["question"], "kind": case["kind"], "technique": "direct_corpus_interaction", **score(case, dci, list(dict.fromkeys(dci_sources)), review)})
        ranked = reranked_answer(case["question"], bm25.search(case["question"], k=20))
        rows.append({"question": case["question"], "kind": case["kind"], "technique": "bm25_reranked", **score(case, ranked, ranked.get("selected_sources", []), review)})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + "\n", encoding="utf-8")
    if args.markdown_output:
        args.markdown_output.parent.mkdir(parents=True, exist_ok=True)
        args.markdown_output.write_text(markdown_report(rows), encoding="utf-8")
    print(json.dumps({"rows": len(rows), "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
