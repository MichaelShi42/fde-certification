"""Retrieval primitives for the Week 3 comparison.

The corpus is synthetic JSONL whose source identifiers are embedded in strings
such as ``DS-214: process coolant pressure boundary design criteria``.  This
module normalises those identifiers and keeps provenance on every hit.
"""

from __future__ import annotations

import json
import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol


TOKEN = re.compile(r"[a-z0-9][a-z0-9_./%-]*", re.I)
SOURCE = re.compile(r"^\s*([^:]+):\s*(.*)$")


@dataclass(frozen=True)
class Record:
    source: str
    title: str
    text: str


@dataclass(frozen=True)
class Hit:
    source: str
    text: str
    score: float


class Retriever(Protocol):
    def search(self, question: str, k: int = 5) -> list[Hit]: ...


def tokenize(text: str) -> list[str]:
    return TOKEN.findall(text.lower())


def load_records(path: str | Path) -> list[Record]:
    """Load and de-duplicate source records from the Week 2 JSONL corpus."""

    by_source: dict[str, Record] = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        inputs = row.get("input", {})
        outputs = row.get("output", {})
        row_text = json.dumps(row, ensure_ascii=False, sort_keys=True)
        for raw_document in inputs.get("documents", []):
            match = SOURCE.match(str(raw_document))
            if match:
                source, title = match.groups()
            else:
                source, title = str(raw_document), str(raw_document)
            existing = by_source.get(source)
            text = f"{title}\n{row_text}"
            if existing is None:
                by_source[source] = Record(source, title, text)
            else:
                by_source[source] = Record(
                    source=existing.source,
                    title=existing.title,
                    text=f"{existing.text}\n{text}",
                )
        # Keep rows with no document list available to a caller as no source;
        # they cannot be cited and therefore are intentionally not indexed.
        _ = outputs
    return list(by_source.values())


class BM25Retriever:
    """Small in-process BM25 index with no external service dependency."""

    def __init__(self, records: list[Record], *, k1: float = 1.5, b: float = 0.75):
        if not records:
            raise ValueError("cannot index an empty corpus")
        self.records = records
        self.k1 = k1
        self.b = b
        self.tokens = [tokenize(record.text) for record in records]
        self.term_frequency = [Counter(tokens) for tokens in self.tokens]
        self.document_frequency = Counter(
            term for tokens in self.tokens for term in set(tokens)
        )
        self.average_length = sum(map(len, self.tokens)) / len(self.tokens)

    def search(self, question: str, k: int = 5) -> list[Hit]:
        query_terms = tokenize(question)
        scored: list[tuple[float, int]] = []
        n_docs = len(self.records)
        for index, frequencies in enumerate(self.term_frequency):
            length = len(self.tokens[index])
            score = 0.0
            for term in query_terms:
                frequency = frequencies.get(term, 0)
                if not frequency:
                    continue
                df = self.document_frequency.get(term, 0)
                idf = math.log(1 + (n_docs - df + 0.5) / (df + 0.5))
                denominator = frequency + self.k1 * (
                    1 - self.b + self.b * length / self.average_length
                )
                score += idf * frequency * (self.k1 + 1) / denominator
            scored.append((score, index))
        scored.sort(key=lambda item: (-item[0], self.records[item[1]].source))
        return [
            Hit(self.records[index].source, self.records[index].text, score)
            for score, index in scored[: max(1, k)]
        ]


class DenseRetriever:
    """Hosted embedding retriever.

    Embeddings are computed lazily and cached in memory.  The caller supplies
    the LiteLLM embedding model and can therefore measure the actual provider,
    token usage, and latency rather than assuming a model is interchangeable.
    """

    def __init__(self, records: list[Record], model: str):
        if not records:
            raise ValueError("cannot index an empty corpus")
        self.records = records
        self.model = model
        self._vectors: list[list[float]] | None = None
        self.embedding_tokens = 0

    @staticmethod
    def _normalise(vector: list[float]) -> list[float]:
        magnitude = math.sqrt(sum(value * value for value in vector))
        if not magnitude:
            raise ValueError("embedding endpoint returned a zero vector")
        return [value / magnitude for value in vector]

    def _embed(self, texts: list[str]) -> list[list[float]]:
        from litellm import embedding

        response = embedding(model=self.model, input=texts)
        usage = getattr(response, "usage", None)
        self.embedding_tokens += int(getattr(usage, "prompt_tokens", 0) or 0)
        data = sorted(response.data, key=lambda item: item["index"])
        return [self._normalise(item["embedding"]) for item in data]

    def search(self, question: str, k: int = 5) -> list[Hit]:
        if self._vectors is None:
            self._vectors = self._embed([record.text for record in self.records])
        query = self._embed([question])[0]
        scored = [
            (sum(left * right for left, right in zip(query, vector)), index)
            for index, vector in enumerate(self._vectors)
        ]
        scored.sort(key=lambda item: (-item[0], self.records[item[1]].source))
        return [
            Hit(self.records[index].source, self.records[index].text, score)
            for score, index in scored[: max(1, k)]
        ]


def reciprocal_rank_fusion(*ranked_lists: list[Hit], k: int = 60) -> list[Hit]:
    """Fuse ranked results without comparing incompatible raw scores."""

    by_source: dict[str, Hit] = {}
    fused: dict[str, float] = {}
    for ranked in ranked_lists:
        for rank, hit in enumerate(ranked, start=1):
            by_source.setdefault(hit.source, hit)
            fused[hit.source] = fused.get(hit.source, 0.0) + 1 / (k + rank)
    return [
        by_source[source]
        for source, _score in sorted(fused.items(), key=lambda item: (-item[1], item[0]))
    ]
