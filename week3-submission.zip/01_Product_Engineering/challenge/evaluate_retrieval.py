"""Run a source-retrieval comparison over the Week 3 labels.

This runner measures retrieval and provenance only.  It deliberately does not
invent answer quality, model latency, or decline behaviour; those are recorded
by the model-backed endpoint evaluation in the next step.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import cast

from retrieval import BM25Retriever, DenseRetriever, load_records, reciprocal_rank_fusion


def load_cases(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def run(technique: str, corpus_path: Path, eval_path: Path, embedding_model: str | None, k: int) -> list[dict]:
    records = load_records(corpus_path)
    bm25 = BM25Retriever(records) if technique in {"bm25", "hybrid"} else None
    dense = (
        DenseRetriever(records, embedding_model)
        if technique in {"dense", "hybrid"} and embedding_model
        else None
    )
    if technique in {"dense", "hybrid"} and dense is None:
        raise ValueError("--embedding-model is required for dense and hybrid techniques")
    if technique in {"bm25", "hybrid"}:
        assert bm25 is not None
    if technique in {"dense", "hybrid"}:
        assert dense is not None
    bm25_index = cast(BM25Retriever, bm25)
    dense_index = cast(DenseRetriever, dense)

    rows = []
    for case in load_cases(eval_path):
        started = time.perf_counter()
        if technique == "bm25":
            hits = bm25_index.search(case["question"], k=k)
        elif technique == "dense":
            hits = dense_index.search(case["question"], k=k)
        else:
            hits = reciprocal_rank_fusion(
                bm25_index.search(case["question"], k=k),
                dense_index.search(case["question"], k=k),
            )[:k]
        elapsed = time.perf_counter() - started
        hit_sources = [hit.source for hit in hits]
        gold = set(case.get("gold", []))
        is_decline = case.get("kind") == "decline"
        rows.append({
            "question": case["question"],
            "kind": case["kind"],
            "technique": technique,
            "retrieved_sources": hit_sources,
            "gold_sources": sorted(gold),
            "source_recall": None if is_decline else len(gold & set(hit_sources)) / len(gold),
            "cited": None if is_decline else gold.issubset(set(hit_sources)),
            "evidence_read": sum(len(hit.text) for hit in hits),
            "latency_seconds": round(elapsed, 6),
            "calls": 0,
            "stop_reason": "retrieval_complete",
        })
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--technique", choices=("bm25", "dense", "hybrid"), required=True)
    parser.add_argument("--corpus", type=Path, default=Path("../../use_case/data/synthetic_v1.jsonl"))
    parser.add_argument("--evals", type=Path, default=Path("../../use_case/evals/retrieval.jsonl"))
    parser.add_argument("--embedding-model")
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = run(args.technique, args.corpus, args.evals, args.embedding_model, args.k)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        "\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "technique": args.technique,
        "questions": len(rows),
        "non_decline_source_recall": [row["source_recall"] for row in rows if row["source_recall"] is not None],
        "output": str(args.output),
    }, indent=2))


if __name__ == "__main__":
    main()
