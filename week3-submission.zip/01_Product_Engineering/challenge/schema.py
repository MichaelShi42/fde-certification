"""The Week 1 contract for the capacity change impact prototype.

The models describe the boundary between the user and the application.  The
implementation of ``solve`` comes after the contract has been reviewed.
"""

from typing import Literal

from pydantic import BaseModel, Field


class Document(BaseModel):
    id: str = Field(min_length=1)
    title: str = Field(min_length=1)
    text: str = Field(min_length=1)


class ProposedChange(BaseModel):
    description: str = Field(min_length=1)
    parameter: str | None = None
    baseline: float | None = None
    proposed: float | None = None
    units: str | None = None
    acceptance_limit: float | None = None
    test_point: float | None = None


class Request(BaseModel):
    """Documents and proposed changes supplied for one impact assessment."""

    documents: list[Document] = Field(
        min_length=1,
        description="Document identifiers, titles, and contents to assess",
    )
    proposed_changes: list[ProposedChange] = Field(
        min_length=1,
        description="Power-capacity change changes, with optional structured values",
    )
    missing_information: list[str] = Field(
        default_factory=list,
        description="Known gaps in the supplied input",
    )


class Citation(BaseModel):
    document_id: str = Field(min_length=1)
    section: str = Field(min_length=1)
    page: int | None = None
    quote: str | None = None


class AffectedItem(BaseModel):
    """One candidate impact that requires engineering review."""

    item: str = Field(description="Affected system, function, component, or requirement")
    type: Literal["system", "function", "component", "requirement", "document"]
    reason: str = Field(description="Why the proposed change may affect this item")
    citations: list[Citation] = Field(
        default_factory=list,
        description="Document sections supporting the candidate impact",
    )
    confidence: Literal["low", "medium", "high"]
    needs_sme_review: bool = True


class Response(BaseModel):
    """Traceable candidate impacts and limitations returned to the engineer."""

    outcome: Literal[
        "candidate_impacts",
        "no_impact_identified",
        "insufficient_evidence",
        "declined",
    ]
    affected_items: list[AffectedItem] = Field(default_factory=list)
    conclusion: str = Field(description="Summary of the assessment or its limitations")
    missing_information: list[str] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)
    needs_sme_review: bool = True
    sources: list[str] = Field(
        default_factory=list,
        description="Every document consulted while producing the response",
    )


def solve(request: Request) -> Response:
    """Assess a proposed capacity change against supplied facility documentation."""

    sources = [document.id for document in request.documents]
    missing = list(request.missing_information)
    has_defined_change = any(
        change.parameter and change.proposed is not None
        for change in request.proposed_changes
    )

    if not has_defined_change:
        if not missing:
            missing = ["A defined parameter change"]
        return Response(
            outcome="declined",
            conclusion=(
                "Decline to provide an impact list until a defined parameter "
                "change and sufficient assessment basis are supplied."
            ),
            missing_information=missing,
            needs_sme_review=True,
            sources=sources,
        )

    if missing:
        return Response(
            outcome="insufficient_evidence",
            conclusion=(
                "Potential impacts may be present, but the supplied evidence "
                "is insufficient for a reliable determination."
            ),
            missing_information=missing,
            limitations=[
                "This baseline implementation does not infer engineering facts "
                "from incomplete documentation."
            ],
            needs_sme_review=True,
            sources=sources,
        )

    citations = [
        Citation(document_id=document.id, section="provided document")
        for document in request.documents
    ]
    return Response(
        outcome="candidate_impacts",
        affected_items=[
            AffectedItem(
                item="Potential capacity change-related facility impact",
                type="system",
                reason=(
                    "The request contains a defined proposed change and supplied "
                    "documents, but engineering review is still required."
                ),
                citations=citations,
                confidence="low",
                needs_sme_review=True,
            )
        ],
        conclusion=(
            "Candidate impact identified from the supplied change and documents; "
            "confirm the affected scope and acceptance basis with an SME."
        ),
        needs_sme_review=True,
        sources=sources,
    )
