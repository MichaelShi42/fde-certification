# Week 1 Technical Challenge

This sanitized submission contains the Week 1 challenge application and its
use-case artifacts.

## Run locally

```bash
cd 01_Product_Engineering/challenge
uv run python app.py
```

The application is available at `http://localhost:7860`.

## Contents

- `01_Product_Engineering/challenge/` — application, schema, frontend, and
  deployment notes
- `use_case/` — charter, decision log, stakeholder notes, ecosystem notes, and
  hand-written golden examples

Internal infrastructure names, repository metadata, and dependency lockfiles
were intentionally excluded from this public-submission branch.
