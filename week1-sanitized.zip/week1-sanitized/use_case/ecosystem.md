# Someone else's ecosystem

Where your application would actually run, inside your actual firm.

> **Week 1 starts this file. Week 9 finishes it.**
> TC1 Step 6 asks eight questions. The full Week 9 checklist has around thirty,
> and the eight are a strict subset — so nothing here gets thrown away.

Describe patterns, not specifics. "On-prem OpenShift, images from an internal
registry, no public egress" is useful to everyone and identifies nobody. Never
put real hostnames, IPs, or architecture diagrams in this file.

---

## Week 1 — the first eight questions

<!-- Answered in TC1 Step 6. Bring these back from a real conversation. -->

**Who did you ask?** (role, not name)

IT infrastructure maintainer

| # | Question | Answer |
| :---: | --- | --- |
| 1 | Where do internal apps run? (k8s, ECS, App Service, a VM someone maintains) | No approved shared runtime for this prototype was identified. The current path is local execution by a small group of technical users. |
| 2 | Which cloud? AWS, Azure, GCP, on-prem, several? | A government cloud environment |
| 3 | Is there an internal container registry? | No approved registry was identified. Docker is not approved on the managed workstation. |
| 4 | How do users log in? (Okta, Entra ID, Ping, SAML, homegrown) | An enterprise directory service |
| 5 | Can the app reach the internet? Egress proxy? Allowlist? | The deployed application will not be allowed to reach the public internet. It will need approved internal services or an allowlisted gateway. |
| 6 | Where do secrets come from? (Vault, Secrets Manager, Key Vault) | The current prototype uses a personal environment variable. A production deployment would need an approved secret store or identity-based mechanism. |
| 7 | Who approves a deployment, and what review does it need? | There is no formal deployment approval or review process |
| 8 | Is there an approved internal LLM endpoint already? | Yes |

**What surprised you?**

The fact that we do not have a formalized process for application deployment and
do not currently have an approved way to containerize an application on the
managed workstation.

**What would you have to change about your app to deploy there?**

For the initial prototype, the application would run locally for a small group
of technical experts and be distributed through an approved source repository. A
production deployment path and shared runtime still need to be defined. The
public LLM API would need to be replaced with the approved organizational LLM
gateway, and Apptainer will be used instead of Docker for the container workflow.

---

## Week 1 — what your machine told you

<!--
  Paste the egress probe output from Session 1 here. It is evidence, and it
  frequently disagrees with what people believe about their own network.
-->

The direct egress probe was run from the challenge environment. Every tested
public host was DNS blocked:

| Host | Status | Error |
| --- | --- | --- |
| `pypi.org` | DNS BLOCKED | `gaierror` |
| `files.pythonhosted.org` | DNS BLOCKED | `gaierror` |
| `api.openai.com` | DNS BLOCKED | `gaierror` |
| `cdn.jsdelivr.net` | DNS BLOCKED | `gaierror` |
| `huggingface.co` | DNS BLOCKED | `gaierror` |
| `registry-1.docker.io` | DNS BLOCKED | `gaierror` |
| `github.com` | DNS BLOCKED | `gaierror` |

The package traffic that succeeded during setup used an approved package proxy,
not direct access to PyPI. The proxy initially failed for the CPU-enabled
PyTorch dependency with `UnknownIssuer` and later returned HTTP 502; a later
`orjson` request timed out. These results show that approved package mirrors are
required for package installation and that the public
model API, frontend CDN, Hugging Face, Docker registry, and GitHub are not
direct runtime dependencies that can be assumed available.

**Does this match what you were told in the table above?** Yes. The direct
probe confirms the reported no-public-internet constraint. The fact that package
installation can work through an approved proxy is a documented exception, not open public
egress.

**Package availability constraint:** The approved package proxy is not currently
serving all packages required by the application environment reliably. A later
`uv sync` request for an `orjson` wheel timed out after repeated retries. The
request also appeared to select a macOS wheel on this Linux x86_64 host, so the
platform selection or proxy metadata needs investigation. As a result, the
Week 1 environment cannot currently be reproduced reliably with `uv sync`. The
application will need either a corrected package proxy, an approved internal
wheelhouse, or pre-approved package artifacts before it can be installed on
this workstation.

---

## Week 9 — the full checklist

<!--
  TC9 extends this same file. Do not start a new one: the point is that the git
  history shows one continuous piece of work from Week 1 to Week 9.
-->

<!-- Week 9 -->
