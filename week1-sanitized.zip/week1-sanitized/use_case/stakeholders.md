# Stakeholders

Everyone you talk to about this project, from the first "where would this even
run?" to the final readout.

> **Week 10's technical challenge is a client report to the people in this file.**
> You cannot write it later from memory. Add a row the day you have the
> conversation.

Use roles, not names. This is a public fork.

| Week | Who (role) | What you asked | What you learned | Follow-up |
| --- | --- | --- | --- | --- |
| 1 | IT infrastructure maintainer | Where would a small internal application run, and what are the constraints around containers, authentication, internet access, secrets, and an organizational LLM gateway? | No approved shared runtime was identified for the prototype. Users rely on an enterprise directory service, public internet access is restricted, Docker is not approved, and an organizational LLM endpoint is available. There is no formal deployment approval process currently identified. | Confirm the approved shared runtime, secret-delivery mechanism, container alternative, and the exact organizational LLM gateway access requirements. |
| 1 | Nuclear systems engineering SME | What would you use this for, what is missing before you would use it, and what would you expect it to cost? | The tool could be very useful for tracing component impact. The main concerns are verifying results, OCR/PDF reliability, and understanding exactly which documents the system viewed. The SME would prefer a simpler UI and a clear audit trail. Expected cost: approximately $200 per year. | Add document-level citations and an audit trail, simplify the UI, and test OCR/PDF handling before broader use. |

---

## Not everyone is an infrastructure contact

The useful list is wider than it first looks, and Week 10's report goes to all of
them:

- **The person with the problem** — the one from your charter. Have you shown
  them anything yet?
- **Whoever owns the data** you would need.
- **Whoever runs the platform** your app would deploy onto.
- **Whoever approves** a deployment, a spend, or a vendor.
- **Your own manager**, who will be asked whether this was worth the ten weeks.

If a week goes by with no conversation, add a row saying so and why. A visible
gap is more useful than a silent one.
