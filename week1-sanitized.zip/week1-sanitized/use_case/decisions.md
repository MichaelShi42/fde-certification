# Decision log

One row per architectural decision, with the option you rejected and why.

> **Week 5 asks you to defend your agent architecture against the alternatives.**
> **Week 10's handoff doc is largely this file.** Both are much easier if you
> wrote the reasoning down while you still remembered it.

A decision without a rejected alternative is not a decision, it is a default.
If you cannot name what you did not do, you did not choose.

| Week | Decision | What you rejected | Why | What would change your mind |
| --- | --- | --- | --- | --- |
| 3 | <!-- retrieval approach --> | <!-- --> | <!-- --> | <!-- --> |
| 5 | Start with a retrieval-and-analysis pipeline, with SME review of every candidate impact | A fully autonomous agent that chooses its own search and investigation steps | The first prototype has a predictable flow: ingest the approved document set, retrieve relevant evidence, analyze the proposed uprate changes, return cited candidate impacts, and flag items for SME review. It does need document search, but the initial workflow does not require open-ended tool selection or autonomous action. The rejected agent approach would add non-deterministic behavior and make results harder to review before there is a baseline. | Evidence that important evaluations require dynamically choosing different tools or investigation paths, or that the fixed workflow repeatedly misses multi-hop relationships that an agent could recover while preserving citations and SME review. |
| 6 | <!-- guardrail level --> | <!-- --> | <!-- --> | <!-- --> |
| 7 | <!-- memory type --> | <!-- --> | <!-- --> | <!-- --> |
| 8 | <!-- model --> | <!-- --> | <!-- --> | <!-- --> |

---

The last column is the one people skip and the one clients ask about. "We chose
dense retrieval; we would switch to hybrid if exact-match queries went above ~20%
of traffic" is an engineering position. "We chose dense retrieval" is a
preference.

## Week 1 counter-argument

The strongest case for an agent is that an extended power uprate may require
following different chains of evidence across heterogeneous documents, and the
system may need to decide whether to search more broadly, ask for another
document, or investigate a related component. If repeated evaluations show that
the fixed pipeline cannot handle those cases without manual orchestration, the
architecture should be reconsidered.

## Week 1 user feedback

The SME demo confirmed that component-impact tracing could be useful, but made
verification the primary product requirement. The prototype should therefore
prioritize a simpler UI, a clear audit trail of documents viewed, document-level
citations, and explicit handling of OCR/PDF reliability. The feedback also
identified an expected annual cost of approximately $200.
