"""The Week 1 contract for the uprate impact prototype.

The models describe the boundary between the user and the application.  The
implementation of ``solve`` comes after the contract has been reviewed.
"""

from typing import Literal

from pydantic import BaseModel, Field


class Request(BaseModel):
    """Documents and proposed changes supplied for one impact assessment."""

    documents: list[str] = Field(
        min_length=1,
        description="Identifiers or contents of the documents to assess",
    )
    proposed_changes: list[str] = Field(
        min_length=1,
        description="Specific power-uprate changes to evaluate",
    )
    missing_information: list[str] = Field(
        default_factory=list,
        description="Known gaps in the supplied input",
    )


class AffectedItem(BaseModel):
    """One candidate impact that requires engineering review."""

    item: str = Field(description="Affected system, function, component, or requirement")
    type: Literal["system", "function", "component", "requirement", "document"]
    reason: str = Field(description="Why the proposed change may affect this item")
    citations: list[str] = Field(
        default_factory=list,
        description="Source document identifiers supporting the candidate impact",
    )
    confidence: Literal["low", "medium", "high"]
    needs_sme_review: bool = True


class Response(BaseModel):
    """Traceable candidate impacts and limitations returned to the engineer."""

    affected_items: list[AffectedItem] = Field(default_factory=list)
    conclusion: str = Field(description="Summary of the assessment or its limitations")
    missing_information: list[str] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)
    needs_sme_review: bool = True


def solve(request: Request) -> Response:
    """Assess a proposed uprate against supplied plant documentation."""

    raise NotImplementedError("implement against this signature")
