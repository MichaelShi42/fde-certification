"""Deterministic checks for the Week 5 subagent alternative."""

from __future__ import annotations

import sys
from pathlib import Path

CHALLENGE = Path(__file__).resolve().parents[1] / "01_Product_Engineering" / "challenge"
sys.path.insert(0, str(CHALLENGE))

import subagents  # noqa: E402
from schema import Document, ProposedChange  # noqa: E402


def _document(document_id: str) -> Document:
    return Document(id=document_id, title=f"Title {document_id}", text=f"Text {document_id}")


def _change() -> ProposedChange:
    return ProposedChange(description="Increase power", parameter="power", proposed=105.0)


def test_subagents_isolate_documents_and_merge_validated_items(monkeypatch):
    def fake_complete(prompt: str) -> str:
        document_id = prompt.split("Document ID: ", 1)[1].splitlines()[0]
        return f"""```json
        {{
          "outcome": "candidate_impacts",
          "affected_items": [{{
            "item": "Item {document_id}",
            "type": "system",
            "reason": "Supported by the document",
            "citations": [{{"document_id": "{document_id}", "section": "1", "quote": "Text {document_id}"}}],
            "confidence": "low",
            "needs_sme_review": true
          }}],
          "conclusion": "Review required",
          "needs_sme_review": true
        }}
        ```"""

    monkeypatch.setattr(subagents, "complete_reply", fake_complete)
    response = subagents.assess_with_subagents([_document("D1"), _document("D2")], [_change()])

    assert response.outcome == "candidate_impacts"
    assert [item.item for item in response.affected_items] == ["Item D1", "Item D2"]
    assert response.sources == ["D1", "D2"]


def test_subagent_rejects_a_citation_outside_its_document(monkeypatch):
    monkeypatch.setattr(
        subagents,
        "complete_reply",
        lambda _prompt: '{"outcome":"candidate_impacts","affected_items":[{"item":"Wrong","type":"system","reason":"x","citations":[{"document_id":"OTHER","section":"1"}],"confidence":"low"}],"conclusion":"x"}',
    )

    response = subagents.assess_with_subagents([_document("D1")], [_change()])

    assert response.outcome == "insufficient_evidence"
    assert response.affected_items == []
    assert any("Subagent failure" in limitation for limitation in response.limitations)


def test_subagent_rejects_a_quote_not_present_in_its_document(monkeypatch):
    monkeypatch.setattr(
        subagents,
        "complete_reply",
        lambda _prompt: '{"outcome":"candidate_impacts","affected_items":[{"item":"Wrong","type":"system","reason":"x","citations":[{"document_id":"D1","section":"1","quote":"not in source"}],"confidence":"low"}],"conclusion":"x"}',
    )

    response = subagents.assess_with_subagents([_document("D1")], [_change()])

    assert response.outcome == "insufficient_evidence"
    assert response.affected_items == []


def test_subagent_rejects_candidate_without_citations(monkeypatch):
    monkeypatch.setattr(
        subagents,
        "complete_reply",
        lambda _prompt: '{"outcome":"candidate_impacts","affected_items":[{"item":"Unsupported","type":"system","reason":"x","citations":[],"confidence":"low"}],"conclusion":"x"}',
    )

    response = subagents.assess_with_subagents([_document("D1")], [_change()])

    assert response.outcome == "insufficient_evidence"
    assert response.affected_items == []


def test_subagent_configuration_falls_back_on_invalid_worker_count(monkeypatch):
    monkeypatch.setenv("SUBAGENT_MAX_WORKERS", "not-an-integer")
    monkeypatch.setattr(
        subagents,
        "complete_reply",
        lambda _prompt: '{"outcome":"no_impact_identified","affected_items":[],"conclusion":"No supported impact"}',
    )
    response = subagents.assess_with_subagents([_document("D1")], [_change()])
    assert response.outcome == "no_impact_identified"
