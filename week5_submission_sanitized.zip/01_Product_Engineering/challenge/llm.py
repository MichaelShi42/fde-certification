"""The model call.

One function, one job: take a conversation, stream back the assistant's reply.

Everything provider-specific lives in environment variables, so switching from
OpenAI to Azure to a self-hosted model is a config change, not a code change.
That property matters more than it looks like it does right now -- see the
"Where does this live?" section of the README.
"""

import json
import os
from dataclasses import dataclass
from threading import Lock

from litellm import completion

# LiteLLM picks the provider from the model string:
#   "gpt-4.1-mini"                    -> OpenAI
#   "azure/my-deployment"             -> Azure OpenAI
#   "anthropic/claude-sonnet-5"       -> Anthropic
#   "ollama/llama3.2"                 -> a model running on your laptop
#   "openai/my-model" + LLM_API_BASE  -> any OpenAI-compatible server (vLLM, LM Studio, ...)
MODEL = os.getenv("LLM_MODEL", "gpt-4.1-mini")
API_BASE = os.getenv("LLM_API_BASE")  # only needed for self-hosted / gateway endpoints
EXTRA_HEADERS = json.loads(os.getenv("LLM_EXTRA_HEADERS") or "{}")

SYSTEM_PROMPT = os.getenv(
    "SYSTEM_PROMPT",
    "You are a helpful assistant. Be concise and concrete.",
)


@dataclass
class ModelMetrics:
    """Process-local counters used by the Week 5 architecture comparison."""

    model_calls: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    capability_calls: int = 0


_METRICS = ModelMetrics()
_METRICS_LOCK = Lock()


def reset_metrics() -> None:
    """Reset counters before one isolated measurement request."""

    with _METRICS_LOCK:
        _METRICS.model_calls = 0
        _METRICS.prompt_tokens = 0
        _METRICS.completion_tokens = 0
        _METRICS.total_tokens = 0
        _METRICS.capability_calls = 0


def snapshot_metrics() -> dict[str, int]:
    """Return a stable copy suitable for an HTTP response."""

    with _METRICS_LOCK:
        return {
            "model_calls": _METRICS.model_calls,
            "prompt_tokens": _METRICS.prompt_tokens,
            "completion_tokens": _METRICS.completion_tokens,
            "total_tokens": _METRICS.total_tokens,
            "capability_calls": _METRICS.capability_calls,
        }


def record_capability_call() -> None:
    with _METRICS_LOCK:
        _METRICS.capability_calls += 1


def _usage_value(usage, name: str) -> int:
    if usage is None:
        return 0
    if isinstance(usage, dict):
        value = usage.get(name, 0)
    else:
        value = getattr(usage, name, 0)
    return int(value or 0)


def _record_model_usage(usage) -> None:
    prompt_tokens = _usage_value(usage, "prompt_tokens")
    completion_tokens = _usage_value(usage, "completion_tokens")
    total_tokens = _usage_value(usage, "total_tokens")
    if not total_tokens:
        total_tokens = prompt_tokens + completion_tokens
    with _METRICS_LOCK:
        _METRICS.prompt_tokens += prompt_tokens
        _METRICS.completion_tokens += completion_tokens
        _METRICS.total_tokens += total_tokens


def _record_model_call() -> None:
    with _METRICS_LOCK:
        _METRICS.model_calls += 1


def stream_reply(message: str, history: list[dict] | None = None):
    """Yield the assistant's reply as it arrives, one growing string at a time.

    `history` is a list of {"role": ..., "content": ...} dicts. We rebuild the
    full message list on every turn -- the model is stateless, so the
    conversation only exists because we keep sending it.
    """
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(history or [])
    messages.append({"role": "user", "content": message})

    kwargs = {
        "model": MODEL,
        "messages": messages,
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    if API_BASE:
        kwargs["api_base"] = API_BASE
    if EXTRA_HEADERS:
        kwargs["extra_headers"] = EXTRA_HEADERS

    _record_model_call()
    reply = ""
    for chunk in completion(**kwargs):
        _record_model_usage(getattr(chunk, "usage", None))
        choices = getattr(chunk, "choices", None) or []
        if not choices:
            continue
        piece = choices[0].delta.content
        if piece:
            reply += piece
            yield reply


def complete_reply(message: str) -> str:
    """Return one non-streamed model response for structured API calls."""

    kwargs = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": message},
        ],
        "stream": False,
    }
    if API_BASE:
        kwargs["api_base"] = API_BASE
    if EXTRA_HEADERS:
        kwargs["extra_headers"] = EXTRA_HEADERS
    _record_model_call()
    response = completion(**kwargs)
    _record_model_usage(getattr(response, "usage", None))
    return (response.choices[0].message.content or "").strip()
