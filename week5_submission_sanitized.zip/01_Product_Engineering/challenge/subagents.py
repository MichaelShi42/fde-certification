"""Bounded document-level subagents for the Week 5 comparison.

The baseline endpoint gives one model call the complete retrieved context.  This
module keeps the same capability and response contract, but gives each selected
document its own model context.  The parent process then performs deterministic
aggregation and citation checks; it does not let a subagent invent a source or
decide what to retrieve next.
"""

from __future__ import annotations

import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from llm import complete_reply, record_capability_call
from schema import AffectedItem, Document, ProposedChange, Response
from validation import insufficient_evidence, validate_assessment


def _json_payload(text: str) -> dict[str, Any]:
    """Parse a JSON object, accepting the fenced output models often return."""

    cleaned = text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()
    payload = json.loads(cleaned)
    if not isinstance(payload, dict):
        raise ValueError("subagent response was not a JSON object")
    return payload


def _document_prompt(document: Document, proposed_changes: list[ProposedChange]) -> str:
    """Build the isolated prompt for one document."""

    return f"""You are a document-analysis subagent for a nuclear uprate review.

Analyze only this document and the proposed changes. Do not use outside
knowledge. Return one JSON object with exactly these fields:
{{
  "outcome": "candidate_impacts|no_impact_identified|insufficient_evidence|declined",
  "affected_items": [
    {{"item":"...", "type":"system|function|component|requirement|document",
     "reason":"...", "citations":[{{"document_id":"{document.id}",
     "section":"...", "page":null, "quote":"..."}}],
     "confidence":"low|medium|high", "needs_sme_review":true}}
  ],
  "conclusion":"...",
  "missing_information":[],
  "limitations":[],
  "needs_sme_review":true
}}

Every affected item must have a citation to this document. Use
"insufficient_evidence" rather than guessing. If this document does not
support an impact, return an empty affected_items list.

Document ID: {document.id}
Document title: {document.title}
Document text:
{document.text}

Proposed changes:
{json.dumps([change.model_dump(exclude_none=True) for change in proposed_changes], indent=2)}
"""


def _analyze_document(
    document: Document,
    proposed_changes: list[ProposedChange],
) -> tuple[str, Response | None]:
    """Run one isolated subagent and validate its result."""

    record_capability_call()
    try:
        response = validate_assessment(
            complete_reply(_document_prompt(document, proposed_changes)), [document]
        )
        return document.id, response
    except Exception as exc:
        return document.id, insufficient_evidence(
            f"Subagent failure: {type(exc).__name__}: {exc}", sources=[document.id]
        )


def assess_with_subagents(
    documents: list[Document],
    proposed_changes: list[ProposedChange],
) -> Response:
    """Assess documents with bounded parallel subagents and deterministic merge."""

    if not documents or not proposed_changes:
        return Response(
            outcome="insufficient_evidence",
            conclusion="Documents and proposed changes are required for assessment.",
            missing_information=["Documents and proposed changes"],
            needs_sme_review=True,
        )

    try:
        configured_workers = int(os.getenv("SUBAGENT_MAX_WORKERS", "4"))
    except ValueError:
        configured_workers = 4
    max_workers = max(1, min(configured_workers, len(documents)))
    results: list[tuple[str, Response]] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(_analyze_document, document, proposed_changes)
            for document in documents
        ]
        for future in as_completed(futures):
            source, response = future.result()
            results.append((source, response or Response(
                outcome="insufficient_evidence",
                conclusion="No validated result was returned.",
                needs_sme_review=True,
                sources=[source],
            )))

    results.sort(key=lambda result: result[0])
    affected_items: list[AffectedItem] = []
    missing_information: list[str] = []
    limitations: list[str] = []
    for _source, response in results:
        affected_items.extend(response.affected_items)
        missing_information.extend(response.missing_information)
        limitations.extend(response.limitations)

    # Preserve order while removing duplicate messages and duplicate items.
    unique_missing = list(dict.fromkeys(missing_information))
    unique_limitations = list(dict.fromkeys(limitations))
    unique_items: list[AffectedItem] = []
    seen_items: set[tuple[str, tuple[tuple[str, str], ...]]] = set()
    for item in affected_items:
        citation_key = tuple(sorted(
            (citation.document_id, citation.section) for citation in item.citations
        ))
        key = (item.item, citation_key)
        if key not in seen_items:
            seen_items.add(key)
            unique_items.append(item)

    if unique_items:
        outcome = "candidate_impacts"
        conclusion = "Candidate impacts were extracted independently and require SME review."
    elif any(response.outcome == "no_impact_identified" for _source, response in results):
        outcome = "no_impact_identified"
        conclusion = "The document-level subagents found no supported candidate impacts."
    else:
        outcome = "insufficient_evidence"
        conclusion = "The document-level subagents could not establish a supported impact."

    return Response(
        outcome=outcome,
        affected_items=unique_items,
        conclusion=conclusion,
        missing_information=unique_missing,
        limitations=unique_limitations,
        needs_sme_review=True,
        sources=[document.id for document in documents],
    )
