"""The server.

`gradio.Server` is a FastAPI app with Gradio's API engine bolted in. You get
queueing, streaming, and MCP for free, but you bring your own frontend. That
split is the point: the API is the product, the UI is disposable.
"""

import os
import json
from pathlib import Path

from fastapi.responses import FileResponse, HTMLResponse
from gradio import Server

from llm import (
    complete_reply,
    record_capability_call,
    reset_metrics,
    snapshot_metrics,
    stream_reply,
)
from retrieval import BM25Retriever, load_records
from schema import Request, Response
from subagents import assess_with_subagents
from validation import insufficient_evidence, validate_assessment

app = Server()

FRONTEND = Path(__file__).parent / "frontend" / "index.html"
CORPUS_PATH = Path(
    os.getenv(
        "RETRIEVAL_CORPUS",
        str(Path(__file__).resolve().parents[2] / "use_case/data/synthetic_v1.jsonl"),
    )
)
RETRIEVER = (
    BM25Retriever(load_records(CORPUS_PATH))
    if CORPUS_PATH.exists()
    else None
)
RERANK_FIRST_STAGE = 20
RERANK_FINAL_STAGE = 5


def rerank_hits(question: str, hits: list, k: int = RERANK_FINAL_STAGE) -> list:
    """Select the final evidence window with the approved chat model."""
    if not hits:
        return []
    candidates = "\n\n---\n\n".join(
        f"[{hit.source}]\n{hit.text[:1600]}" for hit in hits
    )
    prompt = f"""Return only a JSON array of source IDs, ordered best first.
Question: {question}
Candidates:
{candidates}
Select only IDs shown above."""
    try:
        ranked = json.loads(complete_reply(prompt))
        by_source = {hit.source: hit for hit in hits}
        selected = [by_source[source] for source in ranked if source in by_source]
        if selected:
            return selected[: max(1, min(k, RERANK_FINAL_STAGE))]
    except (TypeError, ValueError, json.JSONDecodeError):
        pass
    return hits[: max(1, min(k, RERANK_FINAL_STAGE))]


# --- The API -----------------------------------------------------------------
# The `-> str` return annotation is REQUIRED. Without it Gradio infers zero
# output components and silently returns nothing. Ask us how we know.


@app.api(name="chat")
def chat(message: str, history: list | None = None) -> str:
    """Stream a reply to one user message."""
    yield from stream_reply(message, history)


@app.api(name="assess_uprate_impact")
def assess_uprate_impact(documents: str, proposed_changes: str) -> str:
    """Return a cited, reviewable assessment of possible uprate impacts."""

    try:
        request = Request(
            documents=[json.loads(line) for line in documents.splitlines() if line.strip()],
            proposed_changes=[
                json.loads(line) for line in proposed_changes.splitlines() if line.strip()
            ],
        )
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        # Bad or partially corrupted input should become a reviewable result,
        # not an HTTP/Gradio error with no useful response for the user.
        yield Response(
            outcome="insufficient_evidence",
            conclusion="The uploaded material could not be parsed as a valid assessment request.",
            limitations=[f"Input parsing error: {type(exc).__name__}"],
            needs_sme_review=True,
        ).model_dump_json()
        return
    record_capability_call()
    prompt = f"""Assess a proposed nuclear power uprate using only the supplied information.

Documents:
{json.dumps([document.model_dump() for document in request.documents], indent=2)}

Proposed changes:
{json.dumps([change.model_dump() for change in request.proposed_changes], indent=2)}

Return JSON with this shape:
{{
  "outcome": "candidate_impacts|no_impact_identified|insufficient_evidence|declined",
       "affected_items": [
         {{"item": "...", "type": "system|function|component|requirement|document",
       "reason": "...", "citations": [{{"document_id": "...", "section": "...",
        "page": null, "quote": "exact contiguous text copied from the supplied document"}}],
        "confidence": "low|medium|high", "needs_sme_review": true}}
  ],
  "conclusion": "...",
  "missing_information": [],
  "limitations": [],
  "needs_sme_review": true
}}

Do not invent plant facts. Every candidate impact must have at least one
non-empty citation quote copied exactly from the supplied document, and the
quote must be contiguous source text. Do not use null for a candidate citation
quote. Use "insufficient_evidence" or "declined" when the supplied evidence
does not support candidate impacts, explain what is missing, and set
needs_sme_review to true.
"""
    generated = list(stream_reply(prompt))
    if not generated:
        yield insufficient_evidence("Model returned no response.", sources=[d.id for d in request.documents]).model_dump_json()
        return
    try:
        response = validate_assessment(generated[-1], request.documents)
    except Exception as exc:
        response = insufficient_evidence(
            f"Structured response validation failed: {type(exc).__name__}: {exc}",
            sources=[document.id for document in request.documents],
        )
    yield response.model_dump_json()


@app.api(name="assess_uprate_impact_subagents")
def assess_uprate_impact_subagents(documents: str, proposed_changes: str) -> str:
    """Assess each supplied document in an isolated bounded subagent context."""

    try:
        request = Request(
            documents=[json.loads(line) for line in documents.splitlines() if line.strip()],
            proposed_changes=[
                json.loads(line) for line in proposed_changes.splitlines() if line.strip()
            ],
        )
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        return Response(
            outcome="insufficient_evidence",
            conclusion="The uploaded material could not be parsed as a valid assessment request.",
            limitations=[f"Input parsing error: {type(exc).__name__}"],
            needs_sme_review=True,
        ).model_dump_json()

    return assess_with_subagents(
        request.documents,
        request.proposed_changes,
    ).model_dump_json()


@app.get("/metrics")
def metrics() -> dict[str, int]:
    """Return process-local counters for one architecture measurement."""

    return snapshot_metrics()


@app.post("/metrics/reset")
def metrics_reset() -> dict[str, int]:
    """Clear process-local counters before one architecture measurement."""

    reset_metrics()
    return snapshot_metrics()


@app.api(name="retrieve_uprate_impact")
def retrieve_uprate_impact(question: str, k: int = 5) -> str:
    """Answer one uprate-impact question using retrieved synthetic records.

    The response is JSON matching ``schema.Response``.  Every document returned
    by retrieval is listed in ``sources``.  If the corpus is unavailable or the
    evidence is insufficient, the endpoint declines rather than inventing a
    plant fact.
    """

    if RETRIEVER is None:
        return Response(
            outcome="insufficient_evidence",
            conclusion="The retrieval corpus is not available to this service.",
            limitations=[f"Corpus path not found: {CORPUS_PATH}"],
            needs_sme_review=True,
            sources=[],
        ).model_dump_json()

    first_stage = RETRIEVER.search(question, k=RERANK_FIRST_STAGE)
    if not first_stage or max(hit.score for hit in first_stage) <= 0:
        return Response(
            outcome="declined",
            conclusion="The retrieval corpus contains no evidence that answers this question.",
            missing_information=["A source record relevant to the question"],
            needs_sme_review=True,
            sources=[],
        ).model_dump_json()
    hits = rerank_hits(question, first_stage, k=k)
    sources = [hit.source for hit in hits]
    context = "\n\n---\n\n".join(
        f"[{hit.source}]\n{hit.text}" for hit in hits
    )
    prompt = f"""Assess this nuclear uprate question using only the retrieved evidence.

Question:
{question}

Retrieved evidence:
{context}

Return only valid JSON matching this schema:
{{
  "outcome": "candidate_impacts|no_impact_identified|insufficient_evidence|declined",
  "affected_items": [
    {{"item":"...", "type":"system|function|component|requirement|document",
     "reason":"...", "citations":[{{"document_id":"...", "section":"provided document"}}],
     "confidence":"low|medium|high", "needs_sme_review":true}}
  ],
  "conclusion":"...", "missing_information":[], "limitations":[],
  "needs_sme_review":true
}}

Do not invent engineering facts. If the evidence cannot answer the question,
use "declined" or "insufficient_evidence". Do not add source IDs that are not
present in the retrieved evidence.
"""
    try:
        response = Response.model_validate(json.loads(complete_reply(prompt)))
        cited_sources = {
            citation.document_id
            for item in response.affected_items
            for citation in item.citations
        }
        if response.outcome == "candidate_impacts" and not cited_sources:
            raise ValueError("candidate impacts had no supporting citations")
        if not cited_sources.issubset(set(sources)):
            raise ValueError("response cited a source outside the retrieved evidence")
        response.sources = sources
        return response.model_dump_json()
    except Exception as exc:
        return Response(
            outcome="insufficient_evidence",
            conclusion="The retrieved evidence could not be converted into a valid assessment.",
            limitations=[f"Structured response error: {type(exc).__name__}"],
            needs_sme_review=True,
            sources=sources,
        ).model_dump_json()


# --- The frontend ------------------------------------------------------------
# Defining a route at "/" replaces Gradio's default UI with ours.


@app.get("/", response_class=HTMLResponse)
def homepage() -> str:
    return FRONTEND.read_text(encoding="utf-8")


@app.get("/vendor/gradio-client/index.js", response_class=FileResponse)
def gradio_client_bundle() -> FileResponse:
    """Serve the browser client locally; managed networks may block CDNs."""
    return FileResponse(FRONTEND.parent / "vendor" / "gradio-client" / "index.js")


@app.get("/health")
def health() -> dict:
    """Your future ops team will thank you. Load balancers need this."""
    return {"status": "ok", "model": os.getenv("LLM_MODEL", "gpt-4.1-mini")}


if __name__ == "__main__":
    # 0.0.0.0 so the container is reachable from the host. On your laptop this
    # is fine. On a firm network, "reachable from where, exactly?" is the
    # question this challenge wants you to go ask.
    #
    # Read the port rather than hardcoding it, so a machine that already has
    # something on 7860 can move this one without editing code.
    port = int(os.getenv("GRADIO_SERVER_PORT", "7860"))

    # Gradio announces the address it BOUND to, which is 0.0.0.0 -- not an
    # address a browser can open. Windows rejects it outright; macOS and Linux
    # quietly redirect it to localhost, which is why it looks fine on some
    # machines and broken on others. Print the one that always works.
    print(f"\n  Open http://localhost:{port} in your browser\n", flush=True)
    app.launch(server_name="0.0.0.0", server_port=port)
