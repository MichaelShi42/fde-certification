# Stakeholders

Everyone you talk to about this project, from the first "where would this even
run?" to the final readout.

> **Week 10's technical challenge is a client report to the people in this file.**
> You cannot write it later from memory. Add a row the day you have the
> conversation.

Use roles, not names. This is a public fork.

| Week | Who (role) | What you asked | What you learned | Follow-up |
| --- | --- | --- | --- | --- |
| 1 | IT infrastructure maintainer | Where would a small internal application run, and what are the constraints around containers, authentication, internet access, secrets, and an internal LLM gateway? | The current path is an internal GitLab project that engineers clone and run locally. Azure Gov Cloud is used, LDAP is the current authentication mechanism, public internet access is not allowed, Docker is not approved, and an internal LLM endpoint is available. There is no formal deployment approval process currently identified. | Confirm the approved shared runtime, secret-delivery mechanism, container alternative, and the exact internal LLM gateway access requirements. |
| 1 | Nuclear systems engineering SME | What would you use this for, what is missing before you would use it, and what would you expect it to cost? | The tool could be very useful for tracing component impact. The main concerns are verifying results, OCR/PDF reliability, and understanding exactly which documents the system viewed. The SME would prefer a simpler UI and a clear audit trail. Expected cost: approximately $200 per year. | Add document-level citations and an audit trail, simplify the UI, and test OCR/PDF handling before broader use. Ask for one sanitized past evaluation and its accepted answer key so impact recall can be measured. |
| 2 | Project engineer in charge of the EPU effort | Which examples would never happen, what real input is missing, and what would be concerning if the data were public? | An unreadable sketch of a single system is extremely unlikely in the customer documents. Real evaluations may contain roughly 100 or more plant documents, rather than three or four. The language was vague enough that leakage would not be a major concern. | Remove the unusable-scan axis value, and add document-package size as a follow-up coverage axis before relying on the data for larger evaluations. |
| 3 | Systems engineer | What high-level EPU questions would be useful, and what makes the technical source material difficult to use? | High-level questions are likely to be common. The main difficulty will be converting technical drawings, tables, and figures into a form an LLM can use reliably. Example questions include identifying maximum analyzed operating values, EPU scope, pre-/post-EPU fuel thermal limits, proposed setpoints, and safety-related systems that may limit EPU conditions. | Add multimodal processing for drawings, tables, and figures; validate extracted values against the source material and retain citations for SME review. |
| 4 | Extended-power-uprate SME | Would an outcome-level baseline, source traceability, and explicit insufficient-evidence handling be useful? | The SME identified outcome correctness and valid citations as the minimum defensible checks. The discussion also exposed that six cases cannot establish a production rate and that unreadable OCR must not be presented as a reliable impact. | Obtain a sanitized historical answer key and add the SME's observed failure modes to `failures.md`. |
| 4 | Demo rehearsal stakeholder | What would you change about the web app before using it? | The web app should accept `.txt` file uploads. The chat box is unnecessary. JSON shown to end users should be formatted for readability rather than displayed as raw JSON. | Simplify the UI around file upload and formatted results, then rehearse the revised flow. |
| 5 | Nuclear systems engineering SME | How should the mapper handle document formats, security, impact depth, reactor type, and conflicting conclusions in real uprate reviews? | The direction appears generally promising. Near-term requirements include PDF OCR and ingestion of ZIP packages containing PDF files. The SME asked how data security is maintained, how the mapper determines that a system is impacted, whether it distinguishes direct impacts from deeper-level impacts, whether it distinguishes PWR from BWR, and how it handles conflicting conclusions across documents. Access to relevant materials may not be available until next year because of outage work. | Define the security and impact-taxonomy approach; design PWR/BWR, impact-depth, and conflict-handling tests; plan PDF OCR and ZIP ingestion; follow up when approved materials become available. |

---

## Not everyone is an infrastructure contact

The useful list is wider than it first looks, and Week 10's report goes to all of
them:

- **The person with the problem** — the one from your charter. Have you shown
  them anything yet?
- **Whoever owns the data** you would need.
- **Whoever runs the platform** your app would deploy onto.
- **Whoever approves** a deployment, a spend, or a vendor.
- **Your own manager**, who will be asked whether this was worth the ten weeks.

If a week goes by with no conversation, add a row saying so and why. A visible
gap is more useful than a silent one.
