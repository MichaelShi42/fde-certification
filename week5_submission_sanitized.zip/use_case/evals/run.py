"""Run the Week 5 harness against the local Gradio HTTP endpoint.

Usage:
    EVAL_URL=http://127.0.0.1:7860 python use_case/evals/run.py

The endpoint is expected to expose the Week 1 ``assess_uprate_impact`` API.
If the local Gradio version uses a different route or payload envelope, adjust
``call_endpoint`` rather than changing the scorers.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.request
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from helpers import harness
from use_case.evals.harness import SCORERS, bootstrap_ci


CASES = [
    json.loads(line)
    for line in (ROOT / "use_case/evals/golden.jsonl").read_text(encoding="utf-8").splitlines()
    if line.strip()
]


def call_endpoint(case_input: str) -> str:
    request = json.loads(case_input)
    payload = [
        "\n".join(json.dumps(row) for row in request["documents"]),
        "\n".join(json.dumps(row) for row in request["proposed_changes"]),
    ]
    body = json.dumps({"data": payload}).encode("utf-8")
    endpoint = os.environ.get(
        "EVAL_URL",
        "http://127.0.0.1:7860/gradio_api/call/assess_uprate_impact",
    )
    http_request = urllib.request.Request(
        endpoint,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(http_request, timeout=120) as response:
        event_info = json.loads(response.read().decode("utf-8"))

    event_id = event_info.get("event_id")
    if not event_id:
        raise ValueError(f"Gradio response did not contain an event_id: {event_info}")

    stream_url = endpoint.rstrip("/") + "/" + urllib.parse.quote(event_id, safe="")
    stream_request = urllib.request.Request(
        stream_url,
        headers={"Accept": "text/event-stream"},
        method="GET",
    )
    final_value = None
    with urllib.request.urlopen(stream_request, timeout=120) as response:
        for raw_line in response:
            line = raw_line.decode("utf-8").strip()
            if not line.startswith("data:"):
                continue
            payload = json.loads(line[5:].strip())
            if isinstance(payload, list) and payload:
                final_value = payload[0]
            elif isinstance(payload, str):
                final_value = payload

    if final_value is None:
        raise ValueError("Gradio stream contained no output data")
    return final_value if isinstance(final_value, str) else json.dumps(final_value)


def simulated_sme_endpoint(case_input: str) -> str:
    """Offline rehearsal endpoint when the app dependencies are unavailable.

    This is explicitly not a production measurement: it replays four expert
    answers and deliberately misclassifies the unreadable OCR case.
    """
    request = json.loads(case_input)
    for case in CASES:
        if json.loads(case["input"]) == request:
            expected = json.loads(case["output"])
            if expected.get("outcome") == "insufficient_evidence" and request.get("documents", [{}])[0].get("id") == "DOC-H":
                expected["outcome"] = "declined"
            return json.dumps(expected)
    raise ValueError("simulated endpoint received an unknown case")


def echo(case_input: str) -> str:
    return case_input


def oracle(case_input: str, expected: str) -> str:
    return expected


def evaluate(name: str, system, scorers):
    report = harness.run(CASES, system, scorers, name=name)
    headline = [result.scores["outcome_match"] for result in report.results]
    report.meta["headline"] = "outcome_match"
    report.meta["headline_ci_95"] = bootstrap_ci(headline)
    return report


def main() -> None:
    # The endpoint is scored by a different model from the endpoint itself.
    # Calibration is mandatory; if no model credentials are available, the
    # deterministic contract harness still produces a useful report.
    scorers = dict(SCORERS)
    calibration_text = "judge unavailable: deterministic scorers only"
    try:
        from helpers import nb
        from helpers.judge import Judge
        from use_case.evals.harness import JUDGE_RUBRIC

        judge = Judge(nb.bootstrap(), rubric=JUDGE_RUBRIC)
        calibration = judge.calibrate(CASES, wrong_answer='{"outcome":"candidate_impacts","affected_items":[{"item":"fabricated system","citations":[]}]}')
        calibration_text = str(calibration)
        if calibration.passed:
            scorers["llm_judge"] = judge.as_scorer()
        else:
            calibration_text += " — not used in headline"
    except Exception as exc:
        calibration_text += f" ({type(exc).__name__}: {exc})"

    # Keep the same scorer set for every comparison, including the baseline.
    echo_report = evaluate("echo", echo, scorers)
    oracle_report = evaluate("oracle", lambda value: oracle(value, next(
        case["output"] for case in CASES if case["input"] == value
    )), scorers)
    system = simulated_sme_endpoint if os.getenv("WEEK4_OFFLINE") == "1" else call_endpoint
    report = evaluate("week5-baseline", system, scorers)
    report.meta["judge_calibration"] = calibration_text
    print(echo_report)
    print(oracle_report)
    path = ROOT / "use_case/evals/baseline.json"
    harness.save(report, path)
    print(report)
    print(harness.compare(harness.load(path), report))


if __name__ == "__main__":
    main()
