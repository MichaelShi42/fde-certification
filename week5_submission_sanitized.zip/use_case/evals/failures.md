# Week 5 failure taxonomy

This taxonomy is based on SME review of 20 selected endpoint traces. The current
50-row trace file contains generated robustness probes, not 50 independent real
traces. Eight of the 20 reviewed probes were classified as failures. Fifty
independent real or appropriately anonymized traces will be added in a later
iteration before making natural failure-rate claims.

| Rank | Failure mode | Reviewed count | Reviewed traces | Scorer |
| ---: | --- | ---: | --- | --- |
| 1 | Impact list asserted despite insufficient controlled evidence | 2 | 19, 22 | judge / SME review |
| 2 | Impact list asserted from unreadable OCR or figure evidence | 5 | 27, 29, 30, 32, 34 | judge / SME review |
| 3 | Unresolved preliminary calculation treated as a controlled limit | 1 | 50 | judge / SME review |

These are review-sample counts, not production failure rates. The deterministic
scorers now check response shape, the expected impact list, empty impact lists
for `insufficient_evidence` and `declined`, document IDs, source-supported
quotes, and readable citation text. The headline safety metric is
`evidence_safety`: a response cannot earn credit for a cautious outcome while
still asserting impacts. The calibrated judge and SME review remain necessary,
especially for methodology and applicability. Add the 50 real traces and revise
the counts before using this taxonomy to describe natural failure frequency.

## Judge disagreements to review

The four judge/SME disagreements are a calibration queue, not noise to average
away. For each one, record whether the judge missed an unsupported item, treated
an unreadable quote as evidence, accepted a wrong outcome, or applied the wrong
engineering methodology. Update the rubric only after an SME explains the
decision rule.

## Pilot measures

Recruit SMEs to use the tool on sanitized uprate work now. For each paired
review, record the same case reviewed manually and with the tool:

| Case | Manual minutes | Tool minutes | Rework minutes | SME accepted result? |
| --- | ---: | ---: | ---: | --- |
|  |  |  |  |  |

Report median time and the number of accepted results. Do not claim time saved
from an unpaired estimate or from synthetic cases.
