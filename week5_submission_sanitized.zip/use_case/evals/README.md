# Evals

## `golden.jsonl`

The five core examples plus one public ACRS-derived example are written by
hand. They are not generated.

Each line is one object:

```json
{"input": "...", "output": "...", "why": "what makes this the right answer"}
```

`input` and `output` are always strings. For structured contracts, store their
JSON representation in those strings; do not use objects as dictionary keys in
an oracle. The provisional recall benchmark follows the same convention.

The `why` field is the one that earns its keep. In Week 4 you calibrate an
LLM judge against these, and "why" is what you calibrate it on.

### Why you write these by hand

They are the fixed point of the whole cohort. A model-generated example encodes
what the model already does; a hand-written one encodes what *you* would accept,
which is the only thing worth measuring against.

| Week | What uses this file |
| --- | --- |
| 2 | Seeds for synthetic data generation — your variation axes come from these. |
| 4 | The eval harness scores against them, and the judge is calibrated on them. |
| 6 | Injection regressions get added alongside them. |
| 8 | **The bar.** A fine-tuned open model has to pass the same harness the closed one did. |

Get them wrong now and every number for the next nine weeks is measuring the
wrong thing.

### Writing good ones

- Use **real inputs** from your work, with names and identifiers removed.
- Write the output you would **actually accept**, not an idealized one.
- Include at least one **edge case** and one where the right answer is *"I don't
  know"* or *"escalate this"*. A system that never declines is not calibrated.
- Keep them short enough to read in full during review.

## Impact recall benchmark

`daec_acrs_recall_benchmark.json` is a public, provisional answer key derived
from an ACRS review. Recall is the number of expected technical impacts that
the response identifies, divided by the number of expected impacts. Equivalent
wording counts; unsupported extra items do not. Replace or supplement this case
with one sanitized past evaluation and an accepted SME answer key before making
quality claims.

## Week 5 submission record

This is based on **real SME feedback**. The committed baseline is now produced
by the live Week 3 endpoint over the reviewed cases.

| System | valid response | outcome match | traceability | LLM judge |
| --- | ---: | ---: | ---: | ---: |
| Echo | 0.00 | 0.00 | 1.00 | 0.00 |
| Live Week 3 endpoint baseline | 1.00 | 0.50 | 1.00 | 0.67 |
| Oracle | 1.00 | 1.00 | 1.00 | 1.00 |

The original category-only headline was `outcome_match = 0.50` (3/6). It was
too permissive: case 2 passed despite listing impacts when the golden requires
`insufficient_evidence`. The Week 5 outcome scorer now requires no listed
impacts whenever the golden has none, so the corrected headline is
`2/6 = 0.33` on the reviewed baseline. `impact_match` separately checks that a
candidate list contains the right items rather than merely the right category.
The new headline safety metric is `evidence_safety`: unsupported claims and
non-empty impact lists on cautious outcomes fail it. The calibrated LLM judge
scored the live endpoint at `0.67`; its separation was 1.00 on the accepted
cases and 0.00 on the known-wrong cases. Human calibration examples are in
`human_scores.jsonl`; the taxonomy and judge-disagreement queue are in
`failures.md`. On the 20 SME-reviewed traces, judge/human agreement was `0.80`
(16/20), above the majority-class chance floor of `0.60`.

The selected 20 SME-reviewed traces contained 8 failures. The generator now
produces 16 deterministic probes from the six goldens, including the new
insufficient-evidence and OCR mutations. Detection on the original failure
categories was:

| Failure mode | Cases | valid response | outcome match | impact match | traceability | evidence safety |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| wrong outcome | 4 | 1.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| missing citations | 2 | 1.00 | 1.00 | 1.00 | 0.00 | 0.00 |
| unsupported item | 2 | 1.00 | 1.00 | 0.00 | 0.00 | 0.00 |

The generated suite also includes plausible items on insufficient-evidence
goldens and OCR-garbled quotes. These are deliberate regression probes, not
natural failure rates.

LLM-judge separation is available and passed calibration. It is reported beside
the deterministic headline rather than replacing it.

The endpoint is single-turn and read-only, so multi-turn scenarios are not
applicable; `scenarios.py` records that decision.

## Bring it to work

- **Data:** Fifty sanitized historical uprate-impact assessments reviewed by an extended-power-uprate SME; approval is required before export.
- **Model/endpoint:** The internal Azure Gov LLM gateway and the same Gradio endpoint; judge calls remain inside the approved network. The completed run made 30 judge calls: 12 for calibration and 18 for the echo, oracle, and live endpoint reports.
- **Access/approval:** Read access to controlled engineering records, SME answer-key approval, and platform approval for the internal service and model gateway.
- **Deployment constraints:** No public internet, Docker is not approved, engineers use a local GitLab clone, LDAP is the current authentication mechanism, and model traffic must use the Azure Gov gateway.
- **Immediate validation:** Pair an SME with the tool on sanitized uprate work and record manual versus tool-assisted review time, accepted outcomes, and rework.

Use `review_time.csv` for the paired measurements. Record one `manual` and one
`tool` row for the same `case_id`; report medians only after both rows exist.
