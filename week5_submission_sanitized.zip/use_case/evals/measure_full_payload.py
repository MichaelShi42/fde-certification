"""Measure both architectures using full native document payloads.

Usage, with the challenge app already running:

    python use_case/evals/measure_full_payload.py

This is deliberately separate from ``measure_architectures.py``. The golden
cases contain compact synthetic excerpts; this script loads the full native
text files and records their byte size explicitly.
"""

from __future__ import annotations

import json
import os
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from use_case.evals.run import call_endpoint  # noqa: E402


APP_ROOT = os.environ.get("APP_ROOT", "http://127.0.0.1:7860").rstrip("/")
NATIVE_DIR = ROOT / "use_case/data/native"
OUTPUT = Path(os.environ.get(
    "FULL_MEASURE_OUTPUT",
    str(ROOT / "use_case/evals/full_architecture_measurements.json"),
))

DOCUMENT_IDS = ("ACRSR-1965", "ACRSR-2174", "ACRSR-2195")
PROPOSED_CHANGE = {
    "description": "Evaluate the plant impacts of the extended power uprate.",
    "parameter": "reactor operating power",
    "baseline": 100.0,
    "proposed": 115.3,
    "units": "percent of current operating power",
}


def _native_request(document_ids: tuple[str, ...]) -> dict:
    documents = []
    for document_id in document_ids:
        path = NATIVE_DIR / f"{document_id}.txt"
        text = path.read_text(encoding="utf-8")
        documents.append({
            "id": document_id,
            "title": text.splitlines()[0] if text.splitlines() else document_id,
            "text": text,
        })
    return {
        "documents": documents,
        "proposed_changes": [PROPOSED_CHANGE],
    }


def _get_metrics() -> dict:
    with urllib.request.urlopen(f"{APP_ROOT}/metrics", timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def _reset_metrics() -> None:
    request = urllib.request.Request(f"{APP_ROOT}/metrics/reset", method="POST")
    with urllib.request.urlopen(request, timeout=30) as response:
        response.read()


def _measure(endpoint_name: str, label: str, request: dict, repeat: int) -> dict:
    request_json = json.dumps(request, ensure_ascii=False)
    document_bytes = [
        len(document["text"].encode("utf-8")) for document in request["documents"]
    ]
    os.environ["EVAL_URL"] = f"{APP_ROOT}/gradio_api/call/{endpoint_name}"
    _reset_metrics()
    started = time.perf_counter()
    output = call_endpoint(request_json)
    elapsed = time.perf_counter() - started
    return {
        "implementation": endpoint_name,
        "request": label,
        "documents": len(document_bytes),
        "document_bytes": document_bytes,
        "total_document_bytes": sum(document_bytes),
        "request_bytes": len(request_json.encode("utf-8")),
        "output_bytes": len(output.encode("utf-8")),
        "latency_seconds": round(elapsed, 4),
        "repeat": repeat,
        **_get_metrics(),
    }


def main() -> None:
    repeats = max(1, int(os.environ.get("MEASURE_REPEATS", "1")))
    requests = (
        ("one-full-document", _native_request(DOCUMENT_IDS[:1])),
        ("three-full-documents", _native_request(DOCUMENT_IDS)),
    )
    endpoints = (
        "assess_uprate_impact",
        "assess_uprate_impact_subagents",
    )
    rows = []
    for label, request in requests:
        for endpoint in endpoints:
            for repeat in range(1, repeats + 1):
                row = _measure(endpoint, label, request, repeat)
                rows.append(row)
                print(json.dumps(row, sort_keys=True), flush=True)

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {len(rows)} measurements to {OUTPUT}")


if __name__ == "__main__":
    main()
