"""Measure the Week 5 baseline and Subagent endpoints side by side.

Usage, with the challenge app already running:

    python use_case/evals/measure_architectures.py

The script uses the smallest and largest golden requests by document count so
the comparison includes one and several document-level capability calls. Set
``MEASURE_REPEATS`` for repeated runs. This measures the local app's counters;
it does not estimate token prices.
"""

from __future__ import annotations

import json
import os
import time
import urllib.request
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from use_case.evals.run import call_endpoint  # noqa: E402
APP_ROOT = os.environ.get("APP_ROOT", "http://127.0.0.1:7860").rstrip("/")
OUTPUT = Path(os.environ.get(
    "MEASURE_OUTPUT", str(ROOT / "use_case/evals/architecture_measurements.json")
))


def _get_json(path: str) -> dict:
    with urllib.request.urlopen(f"{APP_ROOT}{path}", timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def _reset_metrics() -> None:
    request = urllib.request.Request(f"{APP_ROOT}/metrics/reset", method="POST")
    with urllib.request.urlopen(request, timeout=30) as response:
        response.read()


def _goldens() -> list[dict]:
    return [
        json.loads(line)
        for line in (ROOT / "use_case/evals/golden.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.strip()
    ]


def _select_requests(cases: list[dict]) -> list[tuple[str, dict]]:
    decoded = [(json.loads(case["input"]), case) for case in cases]
    smallest = min(decoded, key=lambda pair: len(pair[0]["documents"]))
    largest = max(decoded, key=lambda pair: len(pair[0]["documents"]))
    selected = [("single-document", smallest[1])]
    if largest[1] is not smallest[1]:
        selected.append(("multi-document", largest[1]))
    return selected


def _measure(endpoint_name: str, request: dict, label: str) -> dict:
    case_input = json.dumps(request, ensure_ascii=False)
    os.environ["EVAL_URL"] = f"{APP_ROOT}/gradio_api/call/{endpoint_name}"
    _reset_metrics()
    started = time.perf_counter()
    output = call_endpoint(case_input)
    elapsed = time.perf_counter() - started
    metrics = _get_json("/metrics")
    return {
        "implementation": endpoint_name,
        "request": label,
        "documents": len(request["documents"]),
        "input_bytes": len(case_input.encode("utf-8")),
        "output_bytes": len(output.encode("utf-8")),
        "latency_seconds": round(elapsed, 4),
        **metrics,
    }


def main() -> None:
    repeats = max(1, int(os.environ.get("MEASURE_REPEATS", "1")))
    cases = _goldens()
    rows: list[dict] = []
    endpoints = (
        "assess_uprate_impact",
        "assess_uprate_impact_subagents",
    )
    for label, case in _select_requests(cases):
        request = json.loads(case["input"])
        for endpoint in endpoints:
            for repeat in range(1, repeats + 1):
                row = _measure(endpoint, request, label)
                row["repeat"] = repeat
                rows.append(row)
                print(json.dumps(row, sort_keys=True), flush=True)

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {len(rows)} measurements to {OUTPUT}")


if __name__ == "__main__":
    main()
