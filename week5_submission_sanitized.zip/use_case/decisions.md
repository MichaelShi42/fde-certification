# Decision log

One row per architectural decision, with the option you rejected and why.

> **Week 5 asks you to defend your agent architecture against the alternatives.**
> **Week 10's handoff doc is largely this file.** Both are much easier if you
> wrote the reasoning down while you still remembered it.

A decision without a rejected alternative is not a decision, it is a default.
If you cannot name what you did not do, you did not choose.

## Week 5 — what the room asked

### Fair questions

1. **Does the demo clearly communicate the real deployment constraints?**
   The asks slide should include the constraints recorded by stakeholders:
   no public internet, Docker not approved, a local GitLab clone, LDAP, and
   an Azure Government gateway.

2. **Is `outcome_match` the right headline metric, and does the harness catch
   meaningful failures?**
   Not on its own. A case should count as correct only when the outcome
   matches and, when the golden has no items, the response also has no items.
   This catches the failure where impacts were listed despite insufficient
   evidence. The rule changes the headline result from 3/6 to 2/6; the judge
   also passed that case despite scoring 16/20 overall.

### Open question

**How much expert review time does the tool save compared with reviewing
without it?** This requires a comparison with an expert review process.

### Confusion

None identified.

## Week 5 — Step 2: second architecture

### Selected second-best approach: Subagent

The current implementation is the baseline: a predictable retrieval-and-analysis
pipeline with SME review of candidate impacts. The second implementation will
use bounded document-analysis subagents after retrieval. The coordinator will
send each selected document or section to a subagent with a structured output
contract, then aggregate and validate the returned findings and citations.

Subagents are the best alternative for this project because the system must read
long documents but return a relatively small set of evidence-backed impacts.
Separate subagent contexts can keep the parent context clean while preserving
the existing retrieval, citation, unsupported-claim checks, and SME review
stages. The implementation will fan out over selected documents or sections,
not over the entire corpus by default.

The first two ordering questions do not select MCP or UTCP: the capability does
not need discovery by a separate client, and this challenge is not replacing an
existing workplace HTTP API. Skills are the closest rejected alternative. They
would let non-coding SMEs maintain a frequently changing analysis procedure in
natural language, without requiring an engineer to change the implementation.
They are not the selected approach because the main bottleneck in this version
is isolating long-document context, while the workflow itself still needs
structured extraction, citation validation, and deterministic aggregation.
Code Mode could also keep intermediate results out of the model context, but it
would require an approved sandbox for untrusted generated code. MCP adds a
process boundary without a named second client, and a plain tool does not
isolate the long document analyses.

The full native-payload measurement now covers model calls, capability calls,
latency, and tokens at 7,987 bytes for one document and 16,719 bytes for three
documents. Citation validity, unsupported claims, and reviewer usefulness still
require the SME-reviewed evaluation set.

| Week | Decision | What you rejected | Why | What would change your mind |
| --- | --- | --- | --- | --- |
| 3 | BM25 `k=20` with stable-title boost and chat-model reranking to a five-record context | Agentic RAG, direct corpus interaction, and plain BM25 at the endpoint | The pre-fix loader hid generated answers in each record. Source-only synthetic bodies plus supplied ACRS/Turkey Point review chunks now produce 3 missing records at `k=20` and none at `k=50`; the title boost changes ranking without adding evidence. The endpoint uses the measured first stage and reranker, while declines use structured outcome and an empty impact list. | Replace reconstructed bodies with approved native text and rerun the live model-backed comparison; switch to dense/hybrid if reviewed vocabulary-mismatch recall improves within the latency and evidence budget. |
| 5 | Keep the fixed retrieval-and-analysis pipeline, with SME review of every candidate impact | Skills are the closest rejected alternative: they would let non-coding SMEs maintain a changing analysis procedure in natural language. We also built and measured bounded document-level Subagents as the alternative implementation. | At the full native payload, the three-document request contained 16,719 document bytes. The baseline emitted 1 model and capability call, with median 6,615 tokens and 12.3100 seconds. Subagents emitted 3 model and capability calls, with median 10,142 tokens and 23.0288 seconds. The baseline is therefore more predictable, about 1.5x cheaper in tokens, and about 1.9x faster at the measured workload. Skills remain attractive for changing SME-owned procedures, but they do not solve the current long-document context bottleneck by themselves. The measured sample is not production-scale: the expected evaluation package may contain roughly 100 PDFs or more, and a complete representative sample was not available. | Switch to bounded Subagents when a representative full-payload run shows the baseline's combined prompt approaching or exceeding the approved context window, or leaving insufficient response headroom, provided Subagent latency and token use remain within budget. Also switch if Subagents produce a measured improvement in SME-reviewed evidence safety or impact quality large enough to justify their additional calls and tokens. |
| 6 | <!-- guardrail level --> | <!-- --> | <!-- --> | <!-- --> |
| 7 | <!-- memory type --> | <!-- --> | <!-- --> | <!-- --> |
| 8 | <!-- model --> | <!-- --> | <!-- --> | <!-- --> |
| 2 | Dedupe threshold | A lower threshold chosen without inspecting the matched rows | We used character n-gram Jaccard with threshold `0.85`; the generated batch had no dropped rows, so the run did not expose a deduplication boundary. The threshold remains provisional rather than evidence-backed. | A fixed-batch comparison at `0.65`, `0.75`, and `0.85` that shows one threshold removing paraphrases without removing distinct uprate scenarios. |
| 2 | Internal model endpoint for synthetic generation | A public hosted endpoint or a local model that could not reach the approved environment | The generation used the internal Azure Gov-hosted LLM gateway. The current run measured 240 calls, 488,835 total tokens, and 1,149.7 seconds. The internal endpoint is a **constraint** because the application environment has no public internet egress; the model choice is a **preference** until quality and governance are compared against alternatives. The token and elapsed-time figures are **measured**; any price or benchmark comparison would be **looked up**. | A local or alternative approved endpoint that meets the same data-handling constraint while improving quality, latency, cost, or reproducibility. |
| 2 | Synthetic coverage after stakeholder review | Keeping an unusable single-system scan as if it were representative | The project engineer said that input is extremely unlikely in customer packages, so we removed `unusable scan` from the source-extraction axis. The reviewer also identified a coverage gap: real evaluations may contain roughly 100 or more documents, while this version uses only a few. | Add a document-package-size axis and regenerate before using the dataset to make claims about large customer evaluations. |
| 1 | Document input contract | Passing document labels without their contents | Each document carries a required `id`, `title`, and `text`, so a colleague or evaluator can reach a conclusion from the supplied evidence rather than from a label alone. | A retrieval layer may supply these fields from an approved corpus, but the standalone contract still needs the resolved content. |
| 1 | Proposed-change contract | Free text only | Each change carries a required description and optional structured parameter, baseline, proposed value, units, acceptance limit, and test point. Missing structured values can be represented as insufficient evidence rather than guessed. | Repeated production inputs may justify making additional fields required for a specific assessment type. |
| 1 | Citation granularity | Document identifiers without a location | Citations require a document ID and section; page number and quote text remain optional. This gives an engineer a minimum verification location without requiring reliable page extraction in every prototype input. | SME review may require page and quote evidence before production use. |
| 1 | Empty-impact semantics | Treating an empty `affected_items` list as the reason for no result | Responses now carry an explicit outcome: `candidate_impacts`, `no_impact_identified`, `insufficient_evidence`, or `declined`. An empty list alone no longer distinguishes these cases. | Production review may add a separate confidence or evidence-status field if these outcomes remain too coarse. |
| 1 | Impact evaluation metric | Reporting one aggregate quality number despite missed impacts being costlier than extra review items | Measure impact recall against a sanitized SME answer key: matched expected impacts divided by expected impacts, with equivalent wording accepted and no credit for unsupported extras. The public ACRS case is only a provisional benchmark until the SME supplies a past evaluation. | Add precision and severity-weighted recall if the SME distinguishes critical from routine impacts. |
| 4 | Use `outcome_match` as the Week 4 headline, with contract, citation, and calibrated judge checks beside it | F1/substring-style scoring and the LLM judge as the headline | In the extended-power-uprate SME review, outcome correctness is the clearest top failure mode. The live baseline is 0.50 on six cases with bootstrap 95% CI [0.17, 0.83]. The three deterministic scorers passed the oracle at 1.00. The judge passed separation calibration at 1.00 accepted versus 0.00 wrong, scored the live endpoint at 0.67, and agreed with the SME on 16/20 cases (0.80 versus a 0.60 majority-class chance floor); it remains a supporting signal rather than the headline. | Replace the six-case baseline with a larger independent SME-reviewed set, and swap the headline only if the interval narrows and judge agreement remains above the chance floor. |
| 4 | Simplify the web UI to upload `.txt` files and present formatted results without a chat box | Keeping the current chat-first UI, raw JSON display, and no text-file upload path | Demo feedback identified the chat box as unnecessary and raw JSON as difficult for end users to read. A file-upload flow with readable structured results better matches the single-turn assessment workflow. | Reconsider the chat interaction only if users need multi-turn clarification or if a later workflow requires conversational state. |

## Week 5 stakeholder follow-up

The Week 5 refined demo was shown to a nuclear systems engineering SME. The
overall direction was considered promising. The discussion identified the next
product questions rather than resolving them:

- How will data security be maintained?
- How does the mapper determine that a system is impacted?
- Can it distinguish direct impacts from impacts at deeper levels?
- Can it distinguish PWR from BWR?
- Can it handle conflicting conclusions across documents?

The near-term input requirement is PDF OCR, including ingestion of ZIP packages
containing PDF files. Relevant materials may not become available until next
year because the SME is occupied with outage work. These are open requirements,
not claims about capabilities the current prototype already has.

The next design work is to define the security boundary and impact taxonomy,
then create tests for reactor type, impact depth, and conflicting evidence. PDF
OCR and ZIP ingestion should be planned as a separate input pipeline rather
than treated as a change to the current plain-text contract.

---

The last column is the one people skip and the one clients ask about. "We chose
dense retrieval; we would switch to hybrid if exact-match queries went above ~20%
of traffic" is an engineering position. "We chose dense retrieval" is a
preference.

## Week 1 counter-argument

The strongest case for an agent is that an extended power uprate may require
following different chains of evidence across heterogeneous documents, and the
system may need to decide whether to search more broadly, ask for another
document, or investigate a related component. If repeated evaluations show that
the fixed pipeline cannot handle those cases without manual orchestration, the
architecture should be reconsidered.

## Week 1 user feedback

The SME demo confirmed that component-impact tracing could be useful, but made
verification the primary product requirement. The prototype should therefore
prioritize a simpler UI, a clear audit trail of documents viewed, document-level
citations, and explicit handling of OCR/PDF reliability. The feedback also
identified an expected annual cost of approximately $200.

## Week 3 non-text retrieval decision

- **Is the information visual, or text rendered as pixels?** It is genuinely
  visual for scanned figures, diagrams, charts, and other plant-document images;
  some information is not recoverable as reliable text alone.
- **Do important values exist only in pixels?** Yes. Retrieval should find the
  image, then a vision model should read it. Numeric values and identifiers
  require SME or deterministic validation before acceptance.
- **Are descriptions available?** Descriptions should be generated as
  searchable metadata by an approved batch process inside the network, then
  linked back to the original image and reviewed where values affect an
  engineering conclusion.
- **Is video/audio required?** No. Video and audio are outside this MVP.

## Week 3 stakeholder feedback

A systems engineer said that high-level EPU questions are likely to be common,
and identified technical drawings, tables, and figures as the main challenge in
making the source material usable by an LLM. The Week 3 follow-up is therefore to
add multimodal processing for those artifacts, with extracted values checked
against the original source and retained with citations for SME review.
